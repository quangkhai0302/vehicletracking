import { useCallback, useEffect, useRef, useState } from 'react';
import * as fleet from '../services/fleet';
import type { Driver, DriverInput, FleetVehicle, VehicleInput, TripSummary, TripDetail, TripInput, TripAction } from '../types/fleet';
import type { OperationsSnapshot } from '../types/operations';

function newerTrip(local: TripSummary, remote?: TripSummary): TripSummary {
  if (!remote) return local;
  if ((remote.attemptNumber ?? 1) !== (local.attemptNumber ?? 1))
    return (remote.attemptNumber ?? 1) > (local.attemptNumber ?? 1) ? remote : local;
  if (local.status === 'COMPLETED' || local.status === 'CANCELLED') return local;
  if (local.status === 'IN_PROGRESS' && remote.status === 'SCHEDULED') return local;
  return remote;
}

export type FleetScreen = { kind: 'list' } | { kind: 'vehicle-form'; vehicle: FleetVehicle | null }
  | { kind: 'driver-form'; driver: Driver | null }
  | { kind: 'trip-form'; vehicleId: number | null } | { kind: 'trip-detail'; id: number };
export type FleetTab = 'vehicles' | 'drivers' | 'trips';

export function useFleetWorkspace(onToast: (message: string) => void, liveSnapshot?: OperationsSnapshot | null,
  tripSelection?: { tripId: number | null } | null, onTripCreated?: (detail: TripDetail) => void,
  initialTab: FleetTab = 'vehicles', initialVehicleFilter: number | null = null) {
  const [vehicles, setVehicles] = useState<FleetVehicle[]>([]);
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [trips, setTrips] = useState<TripSummary[]>([]);
  const [tab, setTab] = useState<FleetTab>(initialTab);
  const [vehicleFilter, setVehicleFilter] = useState<number | null>(initialVehicleFilter);
  const [screen, setScreen] = useState<FleetScreen>({ kind: 'list' });
  const [detail, setDetail] = useState<TripDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const mounted = useRef(false);
  const busyRef = useRef(false);
  const listAbort = useRef<AbortController | null>(null);
  const detailAbort = useRef<AbortController | null>(null);
  const detailId = useRef(0);
  const [loadAttempt, setLoadAttempt] = useState(0);

  useEffect(() => {
    mounted.current = true;
    return () => { mounted.current = false; listAbort.current?.abort(); detailAbort.current?.abort(); };
  }, []);
  useEffect(() => {
    const controller = new AbortController();
    listAbort.current = controller;
    Promise.all([fleet.fetchFleetVehicles(controller.signal), fleet.fetchDrivers(controller.signal), fleet.fetchTrips(controller.signal)])
    .then(([vehiclesData, driversData, tripsData]) => {
      if (mounted.current && !controller.signal.aborted) { setVehicles(vehiclesData); setDrivers(driversData); setTrips(tripsData); }
    }).catch((err: unknown) => {
      if (mounted.current && !controller.signal.aborted) setError(err instanceof Error ? err.message : 'Không thể tải dữ liệu đội xe.');
    }).finally(() => { if (mounted.current && !controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
  }, [loadAttempt]);
  const reload = () => {
    if (busyRef.current) return;
    setLoading(true); setError(null);
    setLoadAttempt(value => value + 1);
  };

  const clearSelection = useCallback(() => {
    detailId.current++; detailAbort.current?.abort(); setDetail(null); setLoadingDetail(false); setError(null);
  }, []);
  const close = () => { if (busyRef.current) return; clearSelection(); setScreen({ kind: 'list' }); };
  const openVehicleForm = (vehicle: FleetVehicle | null) => {
    if (busyRef.current) return;
    clearSelection(); setScreen({ kind: 'vehicle-form', vehicle });
  };
  const openDriverForm = (driver: Driver | null) => {
    if (busyRef.current) return;
    clearSelection(); setScreen({ kind: 'driver-form', driver });
  };
  const openTripForm = () => {
    if (busyRef.current) return;
    clearSelection(); setScreen({ kind: 'trip-form', vehicleId: vehicleFilter });
  };
  const selectTrip = useCallback(async (id: number) => {
    if (busyRef.current) return;
    clearSelection();
    const token = detailId.current;
    const controller = new AbortController(); detailAbort.current = controller;
    setScreen({ kind: 'trip-detail', id }); setLoadingDetail(true);
    try {
      const data = await fleet.fetchTrip(id, controller.signal);
      if (mounted.current && token === detailId.current && !controller.signal.aborted) {
        setDetail(data); setTrips(current => current.map(trip => trip.id === data.trip.id ? data.trip : trip));
      }
    } catch (err) {
      if (mounted.current && token === detailId.current && !controller.signal.aborted) setError(err instanceof Error ? err.message : 'Không thể tải chuyến.');
    } finally { if (mounted.current && token === detailId.current && !controller.signal.aborted) setLoadingDetail(false); }
  }, [clearSelection]);
  const appliedSelection = useRef<typeof tripSelection>(undefined);
  useEffect(() => {
    // Selection is an explicit UI request, not a lock: the user can still go back to the list.
    // If a mutation is in flight, apply only the latest request after it finishes.
    if (!tripSelection || busy || appliedSelection.current === tripSelection) return;
    appliedSelection.current = tripSelection;
    setTab('trips'); setVehicleFilter(null);
    if (tripSelection.tripId === null) {
      clearSelection(); setScreen({ kind: 'list' });
    } else {
      void selectTrip(tripSelection.tripId);
    }
  }, [tripSelection, busy, selectTrip, clearSelection]);
  const replayNumber = screen.kind === 'trip-detail'
    ? liveSnapshot?.trips.find(trip => trip.id === screen.id)?.attemptNumber ?? 1 : 1;
  useEffect(() => {
    if (!busy && detail && replayNumber > (detail.trip.attemptNumber ?? 1)) void selectTrip(detail.trip.id);
  }, [replayNumber, detail, busy, selectTrip]);
  const mutate = async (operation: () => Promise<void>) => {
    if (busyRef.current) return false;
    busyRef.current = true; listAbort.current?.abort(); setLoading(false);
    setBusy(true); setError(null);
    try { await operation(); return true; }
    catch (err) { if (mounted.current) setError(err instanceof Error ? err.message : 'Thao tác chưa thành công.'); return false; }
    finally { busyRef.current = false; if (mounted.current) setBusy(false); }
  };
  const saveVehicle = (input: VehicleInput, id?: number) => mutate(async () => {
    let saved = id === undefined ? await fleet.createVehicle(input) : await fleet.updateVehicle(id, input);
    const currentDriverId = saved.driver?.id ?? null;
    if (input.driverId !== currentDriverId) {
      try {
        if (input.driverId === null) {
          await fleet.unassignVehicleDriver(saved.id);
          saved = { ...saved, driver: null };
        } else {
          saved = await fleet.assignVehicleDriver(saved.id, input.driverId);
        }
      } catch (error) {
        // Vehicle details and assignment use separate backward-compatible APIs.
        // Refresh after a partial failure so the list reflects committed server state.
        try {
          const refreshed = await fleet.fetchFleetVehicles();
          if (mounted.current) setVehicles(refreshed);
        } catch { /* Preserve the original assignment error. */ }
        throw error;
      }
    }
    if (!mounted.current) return;
    setVehicles(current => [...current.filter(item => item.id !== saved.id), saved].sort((a,b) => a.plateNumber.localeCompare(b.plateNumber)));
    setScreen({ kind: 'list' }); setTab('vehicles'); onToast(id === undefined ? 'Đã thêm xe.' : 'Đã cập nhật xe.');
  });
  const removeVehicle = (vehicle: FleetVehicle) => mutate(async () => {
    await fleet.deactivateVehicle(vehicle.id);
    if (!mounted.current) return;
    setVehicles(current => current.map(item => item.id === vehicle.id ? { ...item, active: false, driver: null } : item));
    onToast(`Đã ngừng sử dụng xe ${vehicle.plateNumber}.`);
  });
  const saveDriver = (input: DriverInput, id?: number) => mutate(async () => {
    const saved = id === undefined ? await fleet.createDriver(input) : await fleet.updateDriver(id, input);
    if (!mounted.current) return;
    setDrivers(current => [...current.filter(item => item.id !== saved.id), saved]
      .sort((a,b) => a.licenseNumber.localeCompare(b.licenseNumber)));
    setVehicles(current => current.map(vehicle => vehicle.driver?.id === saved.id
      ? { ...vehicle, driver: { id: saved.id, fullName: saved.fullName, phoneNumber: saved.phoneNumber, licenseNumber: saved.licenseNumber } }
      : vehicle));
    setScreen({ kind: 'list' }); setTab('drivers');
    onToast(id === undefined ? 'Đã thêm tài xế.' : 'Đã cập nhật tài xế.');
  });
  const removeDriver = (driver: Driver) => mutate(async () => {
    await fleet.deactivateDriver(driver.id);
    if (!mounted.current) return;
    setDrivers(current => current.map(item => item.id === driver.id ? { ...item, active: false } : item));
    onToast(`Đã ngừng sử dụng tài xế ${driver.fullName}.`);
  });
  const saveTrip = (input: TripInput) => mutate(async () => {
    const saved = await fleet.createTrip(input);
    if (!mounted.current) return;
    setTrips(current => [saved.trip, ...current.filter(item => item.id !== saved.trip.id)]);
    setDetail(saved); setTab('trips'); setVehicleFilter(null); setScreen({ kind: 'trip-detail', id: saved.trip.id });
    onTripCreated?.(saved);
    onToast('Đã tạo chuyến đi và lưu lịch trình.');
  });
  const transition = (action: TripAction, reason?: string) => {
    if (!detail) return Promise.resolve(false);
    const id = detail.trip.id;
    return mutate(async () => {
      const saved = await fleet.changeTripStatus(id, action, reason);
      if (!mounted.current) return;
      setDetail(saved); setTrips(current => current.map(item => item.id === id ? saved.trip : item));
      onToast(action === 'start' ? 'Đã ghi nhận khởi hành.' : action === 'complete' ? 'Đã hoàn thành chuyến đi.' : 'Đã hủy chuyến đi.');
    });
  };
  const updateTripSchedule = (id: number, input: { scheduledDepartureAt: string }) => mutate(async () => {
    const saved = await fleet.updateTrip(id, input);
    if (!mounted.current) return;
    setDetail(saved); setTrips(current => current.map(item => item.id === id ? saved.trip : item));
    onToast('Đã cập nhật giờ xuất phát và lịch các điểm dừng.');
  });
  const removeTrip = (id: number) => mutate(async () => {
    await fleet.deleteTrip(id);
    if (!mounted.current) return;
    setTrips(current => current.filter(item => item.id !== id));
    setDetail(null); setScreen({ kind: 'list' });
    onToast('Đã xóa chuyến đi chưa khởi hành.');
  });
  const updateTripDriver = (id: number, driverId: number | null) => mutate(async () => {
    if (driverId === null) {
      await fleet.unassignTripDriver(id);
      if (!mounted.current) return;
      setDetail(current => current?.trip.id === id ? { ...current, trip: { ...current.trip, driver: null } } : current);
      setTrips(current => current.map(item => item.id === id ? { ...item, driver: null } : item));
    } else {
      const saved = await fleet.assignTripDriver(id, driverId);
      if (!mounted.current) return;
      setDetail(saved); setTrips(current => current.map(item => item.id === id ? saved.trip : item));
    }
    onToast(driverId === null ? 'Đã bỏ gán tài xế khỏi chuyến.' : 'Đã cập nhật tài xế của chuyến.');
  });
  const showVehicleTrips = (id: number) => { close(); setVehicleFilter(id); setTab('trips'); };

  const remoteTrips = liveSnapshot?.trips ?? [];
  const mergedTrips = trips.map(trip => newerTrip(trip, remoteTrips.find(item => item.id === trip.id)));
  mergedTrips.push(...remoteTrips.filter(trip => !trips.some(item => item.id === trip.id)));
  mergedTrips.sort((a,b) => Date.parse(b.scheduledDepartureAt) - Date.parse(a.scheduledDepartureAt) || b.id - a.id);
  const visibleDetail = detail && replayNumber <= (detail.trip.attemptNumber ?? 1)
    ? { ...detail, trip: newerTrip(detail.trip, remoteTrips.find(item => item.id === detail.trip.id)) } : null;
  return { vehicles, drivers, trips: mergedTrips, tab, setTab, vehicleFilter, setVehicleFilter, screen, detail: visibleDetail, loading,
    loadingDetail, busy, error, reload, close, openVehicleForm, openDriverForm, openTripForm, selectTrip,
    saveVehicle, removeVehicle, saveDriver, removeDriver, saveTrip, transition, updateTripSchedule, updateTripDriver, removeTrip, showVehicleTrips };
}
