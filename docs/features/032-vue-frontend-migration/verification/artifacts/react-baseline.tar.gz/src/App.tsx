import { lazy, Suspense } from 'react';
import { BrowserRouter, Navigate, Route, Routes, useLocation, useNavigate } from 'react-router-dom';
import { ApplicationShell } from './app/ApplicationShell';
import { AuthProvider } from './auth/AuthContext';
import { RequireAuth } from './auth/RouteGuards';
import { DashboardPage } from './pages/DashboardPage';
import { AlertsManagementPage } from './pages/AlertsManagementPage';
import { FleetManagementPage } from './pages/FleetManagementPage';
import { NotFoundPage } from './pages/NotFoundPage';
import { ReportsPage } from './pages/ReportsPage';
import { ScheduleManagementPage } from './pages/ScheduleManagementPage';
import { LoginPage } from './pages/LoginPage';
import { DriverPortalPage } from './pages/DriverPortalPage';
import { UserManagementPage } from './pages/UserManagementPage';
import { AdminRegistrationPage } from './pages/AdminRegistrationPage';

const MapComponent = lazy(() => import('./components/MapComponent').then(module => ({ default: module.MapComponent })));

function MapPage({ workspace, mapKey }: { workspace: 'tracking' | 'routes' | 'stations'; mapKey: string }) {
  const location = useLocation();
  const navigate = useNavigate();
  const requestedWorkspace = workspace === 'tracking' && new URLSearchParams(location.search).get('mode') === 'simulation' ? 'simulation' : workspace;
  const requestedTripValue = workspace === 'tracking' ? Number(new URLSearchParams(location.search).get('tripId')) : NaN;
  const requestedTripId = Number.isInteger(requestedTripValue) && requestedTripValue > 0 ? requestedTripValue : null;
  const handleWorkspaceChange = (mode: 'tracking' | 'stations' | 'routes' | 'simulation') => {
    if (mode === 'routes' && location.pathname !== '/routes') navigate('/routes');
    else if (mode === 'stations' && location.pathname !== '/stations') navigate('/stations');
    else if (mode === 'tracking' || mode === 'simulation') {
      const targetSearch = mode === 'simulation' ? '?mode=simulation' : '';
      if (location.pathname !== '/operations' || location.search !== targetSearch) {
        navigate(`/operations${targetSearch}`);
      }
    }
  };
  return <div className="business-map-page"><Suspense fallback={<div className="business-map-loading" role="status">Đang tải không gian bản đồ…</div>}>
    <MapComponent key={mapKey} embedded initialWorkspace={requestedWorkspace} initialTripId={requestedTripId} onWorkspaceChange={handleWorkspaceChange} />
  </Suspense></div>;
}

export default function App() {
  return <AuthProvider><BrowserRouter>
    <Routes>
      <Route path="login" element={<LoginPage />} />
      <Route path="register" element={<AdminRegistrationPage />} />
      <Route element={<RequireAuth role="ADMIN" />}>
        <Route element={<ApplicationShell />}>
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="dashboard" element={<DashboardPage />} />
        <Route path="operations" element={<MapPage workspace="tracking" mapKey="operations-map" />} />
        <Route path="vehicles" element={<FleetManagementPage key="vehicles-page" tab="vehicles" />} />
        <Route path="drivers" element={<FleetManagementPage key="drivers-page" tab="drivers" />} />
        <Route path="trips" element={<FleetManagementPage key="trips-page" tab="trips" />} />
        <Route path="routes" element={<MapPage workspace="routes" mapKey="routes-map" />} />
        <Route path="stations" element={<MapPage workspace="stations" mapKey="stations-map" />} />
        <Route path="schedules" element={<ScheduleManagementPage />} />
        <Route path="alerts" element={<AlertsManagementPage />} />
        <Route path="reports" element={<ReportsPage />} />
        <Route path="users" element={<UserManagementPage />} />
        <Route path="*" element={<NotFoundPage />} />
        </Route>
      </Route>
      <Route element={<RequireAuth role="DRIVER" />}>
        <Route path="driver/today" element={<DriverPortalPage />} />
        <Route path="driver/schedules" element={<DriverPortalPage />} />
      </Route>
    </Routes>
  </BrowserRouter></AuthProvider>;
}
