import { useCallback, useEffect, useRef, useState } from 'react';
import { BookOpen, LogOut, Menu, Navigation, PanelLeftClose, PanelLeftOpen } from 'lucide-react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { findRoute, navigationGroups } from './routeConfig';
import { useAuth } from '../auth/AuthContext';
import './application-shell.css';

export function ApplicationShell() {
  const location = useLocation();
  const route = findRoute(location.pathname);
  const { user, logout } = useAuth();
  const [navigationOpen, setNavigationOpen] = useState(false);
  const [mapNavigationExpanded, setMapNavigationExpanded] = useState(false);
  const menuButtonRef = useRef<HTMLButtonElement>(null);
  const sidebarRef = useRef<HTMLElement>(null);
  const sidebarCloseButtonRef = useRef<HTMLButtonElement>(null);
  const closeNavigation = useCallback(() => {
    setNavigationOpen(false);
    if (navigationOpen) window.requestAnimationFrame(() => menuButtonRef.current?.focus());
  }, [navigationOpen]);

  useEffect(() => {
    if (!navigationOpen) return;
    sidebarCloseButtonRef.current?.focus();
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        closeNavigation();
        return;
      }
      if (event.key !== 'Tab') return;
      const focusable = [...(sidebarRef.current?.querySelectorAll<HTMLElement>('a[href],button:not([disabled])') ?? [])]
        .filter(element => element.getClientRects().length > 0);
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (!first || !last) return;
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [navigationOpen, closeNavigation]);

  return <div className={`business-shell${route.fullBleed ? '' : ' business-ui'}`} data-navigation-open={navigationOpen} data-map-focus={route.fullBleed === true} data-map-navigation-expanded={mapNavigationExpanded}>
    {!route.fullBleed && <a className="business-skip-link" href="#main-content">Đi đến nội dung chính</a>}
    <button className="business-shell-overlay" aria-label="Đóng điều hướng" tabIndex={navigationOpen ? 0 : -1} onClick={closeNavigation} />
    <aside ref={sidebarRef} className="business-sidebar" aria-label="Thanh điều hướng ứng dụng">
      <div className="business-brand">
        <span className="business-brand-mark"><Navigation size={19} /></span>
        <span><strong>Vehicle Tracking</strong><small>Operations Manager</small></span>
        <button className="business-map-sidebar-toggle" aria-label={mapNavigationExpanded ? 'Thu gọn thanh điều hướng để mở rộng bản đồ' : 'Mở rộng thanh điều hướng'} aria-expanded={mapNavigationExpanded} onClick={() => setMapNavigationExpanded(value => !value)}>
          {mapNavigationExpanded ? <PanelLeftClose size={19} /> : <PanelLeftOpen size={19} />}
        </button>
        <button ref={sidebarCloseButtonRef} className="business-sidebar-close" aria-label="Đóng điều hướng" onClick={closeNavigation}><PanelLeftClose size={19} /></button>
      </div>
      <nav className="business-navigation" aria-label="Điều hướng chính">
        {navigationGroups.map(group => <section key={group.label}>
          <h2>{group.label}</h2>
          {group.items.map(item => {
            const Icon = item.icon;
            return <NavLink key={item.path} to={item.path} title={route.fullBleed && !mapNavigationExpanded ? item.label : undefined} aria-label={route.fullBleed && !mapNavigationExpanded ? item.label : undefined} onClick={closeNavigation} className={({ isActive }) => isActive ? 'active' : undefined}>
              <Icon size={18} />
              <span>{item.label}</span>
              {item.planned && <small>Roadmap</small>}
            </NavLink>;
          })}
        </section>)}
      </nav>
      <a className="business-guide-link" href="/huong-dan/index.html" target="_blank" rel="noreferrer"><BookOpen size={17} /><span>Hướng dẫn sử dụng</span></a>
    </aside>
    <div className="business-shell-main">
      <header className="business-topbar">
        <button ref={menuButtonRef} className="business-menu-button" aria-label="Mở điều hướng" aria-expanded={navigationOpen} onClick={() => setNavigationOpen(true)}><Menu size={20} /></button>
        <div className="business-topbar-copy">
          <span>{route.planned ? 'LỘ TRÌNH SẢN PHẨM' : 'TRUNG TÂM ĐIỀU HÀNH'}</span>
          <h1>{route.title}</h1>
          <p>{route.description}</p>
        </div>
        <div className="business-account"><span>{user?.username}</span><small>ADMIN</small><button aria-label="Đăng xuất" onClick={() => void logout()}><LogOut size={15} /></button></div>
      </header>
      <main id="main-content" tabIndex={route.fullBleed ? undefined : -1} className={route.fullBleed ? 'business-content business-content-full' : 'business-content'}>
        <Outlet />
      </main>
    </div>
  </div>;
}
