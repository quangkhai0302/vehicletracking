import { useState, type FormEvent } from 'react';
import { ArrowLeft, Save } from 'lucide-react';
import type { Driver, DriverInput } from '../../types/fleet';
import { FleetConfirmDialog } from './FleetConfirmDialog';

export function DriverEditor({ driver, busy, error, onSave, onClose }: {
  driver: Driver | null;
  busy: boolean;
  error: string | null;
  onSave: (input: DriverInput, id?: number) => Promise<boolean>;
  onClose: () => void;
}) {
  const [fullName, setFullName] = useState(driver?.fullName ?? '');
  const [phoneNumber, setPhoneNumber] = useState(driver?.phoneNumber ?? '');
  const [licenseNumber, setLicenseNumber] = useState(driver?.licenseNumber ?? '');
  const [confirm, setConfirm] = useState(false);
  const normalizedLicense = licenseNumber.trim().toUpperCase();
  const validPhone = /^\+?[0-9][0-9 .()-]{6,19}$/.test(phoneNumber.trim());
  const validLicense = /^[A-Z0-9.-]{1,50}$/.test(normalizedLicense);
  const dirty = fullName !== (driver?.fullName ?? '') || phoneNumber !== (driver?.phoneNumber ?? '') || licenseNumber !== (driver?.licenseNumber ?? '');
  const close = () => { if (dirty) setConfirm(true); else onClose(); };
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (busy || !fullName.trim() || !validPhone || !validLicense) return;
    void onSave({ fullName: fullName.trim(), phoneNumber: phoneNumber.trim(), licenseNumber: normalizedLicense }, driver?.id);
  };

  return <section className="fleet-editor" aria-label={driver ? 'Chỉnh sửa tài xế' : 'Thêm tài xế mới'}>
    <div className="fleet-heading"><button className="fleet-icon-button" aria-label="Đóng biểu mẫu tài xế" onClick={close} disabled={busy}><ArrowLeft size={18} /></button>
      <div><span className="panel-eyebrow">NHÂN SỰ VẬN HÀNH</span><h2>{driver ? 'Chỉnh sửa tài xế' : 'Thêm tài xế mới'}</h2></div></div>
    <form id="driver-form" className="fleet-form-body" onSubmit={submit}><fieldset disabled={busy}>
      {error && <p role="alert" className="fleet-error">{error}</p>}
      <label>Họ và tên *<input name="fullName" value={fullName} maxLength={100} required placeholder="Ví dụ: Nguyễn Văn An" onChange={event => setFullName(event.target.value)} /></label>
      <label>Số điện thoại *<input name="phoneNumber" value={phoneNumber} minLength={7} maxLength={20} required placeholder="Ví dụ: 0901 234 567" onChange={event => setPhoneNumber(event.target.value)} /></label>
      <label>Số GPLX *<input name="licenseNumber" value={licenseNumber} maxLength={50} required pattern="[A-Za-z0-9.-]+" placeholder="Ví dụ: B2-123456" onChange={event => setLicenseNumber(event.target.value)} /></label>
      <p className="fleet-help">Số GPLX được chuẩn hóa viết hoa và không thể trùng với tài xế đã ngừng sử dụng.</p>
    </fieldset></form>
    <div className="fleet-footer"><button className="btn-secondary" disabled={busy} onClick={close}>Hủy</button>
      <button className="btn-primary" type="submit" form="driver-form" disabled={busy || !fullName.trim() || !validPhone || !validLicense}><Save size={15} />{busy ? 'Đang lưu…' : driver ? 'Lưu tài xế' : 'Thêm tài xế'}</button></div>
    {confirm && <FleetConfirmDialog title="Bỏ thay đổi của tài xế?" message="Thông tin chưa lưu sẽ bị xóa." confirmLabel="Bỏ thay đổi" busy={false} onConfirm={onClose} onClose={() => setConfirm(false)} />}
  </section>;
}
