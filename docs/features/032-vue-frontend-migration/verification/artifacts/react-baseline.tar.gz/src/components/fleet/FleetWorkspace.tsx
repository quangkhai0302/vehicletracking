import { useState } from 'react';
import { ArrowRight, BusFront, CalendarDays, CarFront, CheckCircle2, Edit3, Plus, RefreshCw, Scooter, Search, Trash2, UserRound } from 'lucide-react';
import type { Driver, FleetVehicle, TripDetail, TripStatus } from '../../types/fleet';
import { TRIP_STATUS_LABELS, vehicleTypeLabel } from '../../types/fleet';
import { useFleetWorkspace, type FleetTab } from '../../hooks/useFleetWorkspace';
import { displayTripTime } from '../../utils/tripTime';
import { VehicleEditor } from './VehicleEditor';
import { TripEditor } from './TripEditor';
import { TripDetailPanel } from './TripDetailPanel';
import { FleetConfirmDialog } from './FleetConfirmDialog';
import { DriverEditor } from './DriverEditor';
import './fleet.css';
import type { OperationsSnapshot } from '../../types/operations';
import { FleetManagementTable } from '../business/FleetManagementTable';

export function FleetWorkspace({ onToast, onFocusStop, onManageRoutes, onManageStations, liveSnapshot, onSimulateTrip, onFocusVehicle, tripSelection, onTripCreated, initialTab = 'vehicles', initialVehicleFilter = null, lockedTab, onViewVehicleTrips, onClearVehicleFilter }: {
  onToast: (message: string) => void;
  onFocusStop: (position: [number, number], zoom?: number) => void;
  onManageRoutes: () => void; onManageStations: () => void;
  liveSnapshot?: OperationsSnapshot | null; onSimulateTrip?: (id: number) => void; onFocusVehicle?: (id: number) => void;
  tripSelection?: { tripId: number | null } | null; onTripCreated?: (detail: TripDetail) => void;
  initialTab?: FleetTab; initialVehicleFilter?: number | null; lockedTab?: FleetTab; onViewVehicleTrips?: (vehicleId: number) => void; onClearVehicleFilter?: () => void;
}) {
  const fleet = useFleetWorkspace(onToast, liveSnapshot, tripSelection, onTripCreated, initialTab, initialVehicleFilter);
  const activeTab = lockedTab ?? fleet.tab;
  const [query, setQuery] = useState('');
  const [vehicleStatus, setVehicleStatus] = useState<'active' | 'inactive' | 'all'>('active');
  const [driverStatus, setDriverStatus] = useState<'active' | 'inactive' | 'all'>('active');
  const [tripStatus, setTripStatus] = useState<TripStatus | ''>('');
  const [deactivate, setDeactivate] = useState<FleetVehicle | null>(null);
  const [deactivateDriver, setDeactivateDriver] = useState<Driver | null>(null);
  const { screen } = fleet;
  const q = query.trim().toLocaleLowerCase('vi');
  const vehicles = fleet.vehicles.filter(vehicle => (vehicleStatus === 'all' || vehicle.active === (vehicleStatus === 'active')) &&
    (!q || `${vehicle.plateNumber} ${vehicle.name} ${vehicle.driver?.fullName ?? ''}`.toLocaleLowerCase('vi').includes(q)));
  const drivers = fleet.drivers.filter(driver => (driverStatus === 'all' || driver.active === (driverStatus === 'active')) &&
    (!q || `${driver.fullName} ${driver.phoneNumber} ${driver.licenseNumber}`.toLocaleLowerCase('vi').includes(q)));
  const trips = fleet.trips.filter(trip => (!fleet.vehicleFilter || trip.vehicleId === fleet.vehicleFilter) && (!tripStatus || trip.status === tripStatus) &&
    (!q || `${trip.id} ${trip.vehiclePlateNumber} ${trip.routeName}`.toLocaleLowerCase('vi').includes(q)));
  const filteredVehicle = fleet.vehicles.find(vehicle => vehicle.id === fleet.vehicleFilter);
  const hasFilters = Boolean(query.trim() || (activeTab === 'vehicles' && vehicleStatus !== 'active') || (activeTab === 'drivers' && driverStatus !== 'active') || (activeTab === 'trips' && (tripStatus || fleet.vehicleFilter)));
  const clearVehicleFilter = () => { fleet.setVehicleFilter(null); if (activeTab === 'trips') onClearVehicleFilter?.(); };
  const clearFilters = () => { setQuery(''); setVehicleStatus('active'); setDriverStatus('active'); setTripStatus(''); clearVehicleFilter(); };
  const moduleCopy = activeTab === 'vehicles'
    ? { eyebrow: 'ĐỘI XE', title: 'Phương tiện', description: 'Quản lý danh mục xe, trạng thái sử dụng và phân công hiện tại.', icon: BusFront, primary: 'Thêm phương tiện', total: fleet.vehicles.length, primaryAction: () => fleet.openVehicleForm(null) }
    : activeTab === 'drivers'
      ? { eyebrow: 'NHÂN SỰ VẬN HÀNH', title: 'Tài xế', description: 'Theo dõi hồ sơ, giấy phép và xe đang được phân công.', icon: UserRound, primary: 'Thêm tài xế', total: fleet.drivers.length, primaryAction: () => fleet.openDriverForm(null) }
      : { eyebrow: 'LỊCH VẬN HÀNH', title: 'Chuyến đi', description: 'Lập chuyến, phân công và theo dõi vòng đời vận hành.', icon: CalendarDays, primary: 'Tạo chuyến đi', total: fleet.trips.length, primaryAction: fleet.openTripForm };
  const ModuleIcon = moduleCopy.icon;
  const activeCount = activeTab === 'vehicles' ? fleet.vehicles.filter(vehicle => vehicle.active).length
    : activeTab === 'drivers' ? fleet.drivers.filter(driver => driver.active).length
      : fleet.trips.filter(trip => trip.status === 'IN_PROGRESS').length;
  const activeLabel = activeTab === 'vehicles' ? 'đang sử dụng' : activeTab === 'drivers' ? 'đang hoạt động' : 'đang chạy';
  const filteredCount = activeTab === 'vehicles' ? vehicles.length : activeTab === 'drivers' ? drivers.length : trips.length;
  const hasActiveVehicle = fleet.vehicles.some(vehicle => vehicle.active);
  const primaryDisabled = fleet.loading || !!fleet.error || (activeTab === 'trips' && !hasActiveVehicle);

  return <div className="fleet-workspace">
    <div className="fleet-list-view" hidden={screen.kind !== 'list'}>
      <header className="fleet-module-header">
        <div className="fleet-module-title"><span className="fleet-module-icon"><ModuleIcon size={21} /></span><div><span className="fleet-module-eyebrow">{moduleCopy.eyebrow}</span><h2>{moduleCopy.title}</h2><p>{moduleCopy.description}</p></div></div>
        <div className="fleet-module-summary"><div><strong>{activeCount}</strong><span>{activeLabel}</span></div><div><strong>{moduleCopy.total}</strong><span>tổng danh mục</span></div></div>
        <div className="fleet-module-actions"><button className="fleet-refresh-button" disabled={fleet.loading || fleet.busy} aria-label={`Tải lại ${moduleCopy.title.toLocaleLowerCase('vi')}`} onClick={() => void fleet.reload()}><RefreshCw size={16} /></button><button className="fleet-primary-action" disabled={primaryDisabled} title={activeTab === 'trips' && !hasActiveVehicle ? 'Cần có ít nhất một xe đang sử dụng' : undefined} onClick={moduleCopy.primaryAction}><Plus size={16} />{moduleCopy.primary}</button></div>
      </header>
      {!lockedTab && <div className="planning-tabs fleet-tabs" aria-label="Quản lý đội xe">
        <button aria-pressed={activeTab === 'vehicles'} onClick={() => { fleet.setTab('vehicles'); setQuery(''); }}><BusFront size={14} />Đội xe <span>{fleet.vehicles.filter(vehicle => vehicle.active).length}</span></button>
        <button aria-pressed={activeTab === 'drivers'} onClick={() => { fleet.setTab('drivers'); setQuery(''); }}><UserRound size={14} />Tài xế <span>{fleet.drivers.filter(driver => driver.active).length}</span></button>
        <button aria-pressed={activeTab === 'trips'} onClick={() => { fleet.setTab('trips'); setQuery(''); }}><CalendarDays size={14} />Chuyến đi <span>{fleet.trips.length}</span></button>
      </div>}
      <div className="fleet-heading"><div><span className="panel-eyebrow">DANH SÁCH HIỂN THỊ</span><h2>{filteredCount} kết quả{hasFilters ? ' phù hợp' : ''}</h2></div><span className="fleet-list-hint"><CheckCircle2 size={14} /> Dữ liệu hiện tại</span></div>
      <div className="fleet-list-tools">
        <label className="fleet-search"><Search size={15} /><input aria-label={activeTab === 'vehicles' ? 'Tìm xe' : activeTab === 'drivers' ? 'Tìm tài xế' : 'Tìm chuyến đi'} placeholder={activeTab === 'vehicles' ? 'Biển số, tên xe hoặc tài xế…' : activeTab === 'drivers' ? 'Tên, điện thoại hoặc GPLX…' : 'Biển số, tuyến hoặc mã chuyến…'} value={query} onChange={e => setQuery(e.target.value)} /></label>
        {activeTab === 'vehicles' ? <select aria-label="Lọc xe" value={vehicleStatus} onChange={e => setVehicleStatus(e.target.value as typeof vehicleStatus)}>
          <option value="active">Đang sử dụng</option><option value="inactive">Đã ngừng sử dụng</option><option value="all">Tất cả xe</option>
        </select> : activeTab === 'drivers' ? <select aria-label="Lọc tài xế" value={driverStatus} onChange={event => setDriverStatus(event.target.value as typeof driverStatus)}>
          <option value="active">Đang hoạt động</option><option value="inactive">Đã ngừng hoạt động</option><option value="all">Tất cả tài xế</option>
        </select> : <>
          <select aria-label="Lọc trạng thái chuyến" value={tripStatus} onChange={e => setTripStatus(e.target.value as TripStatus | '')}>
            <option value="">Mọi trạng thái</option>{Object.entries(TRIP_STATUS_LABELS).map(([id,label]) => <option key={id} value={id}>{label}</option>)}
          </select>
          {fleet.vehicleFilter && <div className="fleet-filter-chip"><span>Xe {filteredVehicle?.plateNumber ?? fleet.vehicleFilter}</span><button onClick={clearVehicleFilter}>Bỏ lọc xe</button></div>}
        </>}
        {hasFilters && <button className="fleet-clear-filters" onClick={clearFilters}>Xóa bộ lọc</button>}
      </div>
      <div className="fleet-list-body" aria-busy={fleet.loading}>
        {fleet.loading && <p className="fleet-loading" role="status">Đang tải xe và chuyến đi…</p>}
        {fleet.error && !deactivate && !deactivateDriver && <div className="fleet-error" role="alert">{fleet.error}<button className="fleet-text-button" onClick={() => void fleet.reload()}>Thử lại</button></div>}
        {!fleet.loading && !fleet.error && lockedTab && <FleetManagementTable tab={activeTab} vehicles={vehicles} allVehicles={fleet.vehicles} drivers={drivers} trips={trips}
          onEditVehicle={fleet.openVehicleForm} onDeactivateVehicle={setDeactivate}
          onVehicleTrips={id => { setQuery(''); if (onViewVehicleTrips) onViewVehicleTrips(id); else fleet.showVehicleTrips(id); }}
          onEditDriver={fleet.openDriverForm} onDeactivateDriver={setDeactivateDriver} onTrip={id => { void fleet.selectTrip(id); }} />}
        {!lockedTab && !fleet.loading && !fleet.error && activeTab === 'vehicles' && <>
          {vehicles.length === 0 && <div className="fleet-empty"><BusFront size={30} /><h3>{fleet.vehicles.length ? 'Không tìm thấy xe phù hợp' : 'Chưa có xe trong danh mục'}</h3><p>Thêm xe, sau đó tạo chuyến từ tuyến đã lưu.</p><button className="fleet-text-button" onClick={onManageStations}>Thiết lập trạm</button></div>}
          {vehicles.map(vehicle => <article key={vehicle.id} className="fleet-vehicle-card">
            <div className="fleet-card-main"><button className="fleet-vehicle-select" onClick={() => { setQuery(''); if (onViewVehicleTrips) onViewVehicleTrips(vehicle.id); else fleet.showVehicleTrips(vehicle.id); }}>
              <span className="fleet-plate">{vehicle.vehicleType === 'MOTORCYCLE' ? <Scooter size={16} /> : <CarFront size={16} />}{vehicle.plateNumber}</span><strong>{vehicle.name}</strong>
              <span className="fleet-help">{vehicleTypeLabel(vehicle.vehicleType)} · {vehicle.active ? 'Đang sử dụng' : 'Đã ngừng sử dụng'} · {liveSnapshot == null ? 'Realtime xem tại Giám sát trực tiếp' : liveSnapshot.positions.some(point => point.vehicleId === vehicle.id) ? 'Đã nhận vị trí' : 'Chưa có vị trí xe'}</span>
              <span className="fleet-help">Tài xế: {vehicle.driver?.fullName ?? 'Chưa gán'}</span>
            </button>
            {vehicle.active && <div className="fleet-card-actions"><button className="fleet-icon-button" aria-label={`Sửa xe ${vehicle.plateNumber}`} onClick={() => fleet.openVehicleForm(vehicle)}><Edit3 size={15} /></button>
              <button className="fleet-icon-button danger" aria-label={`Ngừng sử dụng xe ${vehicle.plateNumber}`} onClick={() => setDeactivate(vehicle)}><Trash2 size={15} /></button></div>}</div>
            {vehicle.description && <p className="fleet-card-description">{vehicle.description}</p>}
            {liveSnapshot?.positions.some(point => point.vehicleId === vehicle.id) && <button className="fleet-text-button" onClick={() => onFocusVehicle?.(vehicle.id)}>Xem vị trí xe</button>}
            <button className="fleet-text-button" onClick={() => { setQuery(''); if (onViewVehicleTrips) onViewVehicleTrips(vehicle.id); else fleet.showVehicleTrips(vehicle.id); }}>Xem chuyến đi <span>→</span></button>
          </article>)}
        </>}
        {!lockedTab && !fleet.loading && !fleet.error && activeTab === 'drivers' && <>
          {drivers.length === 0 && <div className="fleet-empty"><UserRound size={30} /><h3>{fleet.drivers.length ? 'Không tìm thấy tài xế phù hợp' : 'Chưa có tài xế'}</h3><p>Thêm tài xế để phân công cho xe và chuyến đi.</p></div>}
          {drivers.map(driver => {
            const assignedVehicle = fleet.vehicles.find(vehicle => vehicle.active && vehicle.driver?.id === driver.id);
            return <article key={driver.id} className="fleet-driver-card"><div className="fleet-card-main"><div className="fleet-driver-main">
              <span className="fleet-driver-license"><UserRound size={15} />{driver.licenseNumber}</span><strong>{driver.fullName}</strong>
              <span className="fleet-help">{driver.phoneNumber} · {driver.active ? 'Đang hoạt động' : 'Đã ngừng hoạt động'}</span>
              <span className="fleet-help">Xe hiện tại: {assignedVehicle ? `${assignedVehicle.plateNumber} · ${assignedVehicle.name}` : 'Chưa gán'}</span>
            </div>{driver.active && <div className="fleet-card-actions"><button className="fleet-icon-button" aria-label={`Sửa tài xế ${driver.fullName}`} onClick={() => fleet.openDriverForm(driver)}><Edit3 size={15} /></button>
              <button className="fleet-icon-button danger" aria-label={`Ngừng tài xế ${driver.fullName}`} onClick={() => setDeactivateDriver(driver)}><Trash2 size={15} /></button></div>}</div></article>;
          })}
        </>}
        {!lockedTab && !fleet.loading && !fleet.error && activeTab === 'trips' && <>
          {trips.length === 0 && <div className="fleet-empty"><CalendarDays size={30} /><h3>Chưa có chuyến phù hợp</h3><p>Chọn xe, tuyến và giờ xuất phát để lập lịch trình.</p></div>}
          {trips.map(trip => <button key={trip.id} className="fleet-trip-card" aria-label={`Mở chi tiết chuyến ${trip.id}, ${trip.routeName}`} onClick={() => void fleet.selectTrip(trip.id)}>
            <span className="fleet-trip-title"><strong>#{trip.id} · {trip.vehiclePlateNumber}</strong><span className={`trip-status ${trip.status.toLowerCase()}`}>{TRIP_STATUS_LABELS[trip.status]}</span></span>
            <span className="fleet-trip-route">{trip.routeName}</span><span className="fleet-help">Xuất phát {displayTripTime(trip.scheduledDepartureAt)}</span>
            <span className="fleet-help">Tài xế: {trip.driver?.fullName ?? 'Chưa gán'}</span>
            <span className="fleet-help">Theo lịch: {displayTripTime(trip.plannedEndAt)}</span><ArrowRight className="fleet-card-arrow" size={16} aria-hidden="true" />
          </button>)}
        </>}
      </div>
      <div className="fleet-footer fleet-list-footer">
        {activeTab === 'vehicles' ? <button className="btn-primary" disabled={fleet.loading || !!fleet.error} onClick={() => fleet.openVehicleForm(null)}><Plus size={16} />Thêm xe mới</button>
          : activeTab === 'drivers' ? <button className="btn-primary" disabled={fleet.loading || !!fleet.error} onClick={() => fleet.openDriverForm(null)}><Plus size={16} />Thêm tài xế mới</button>
          : <button className="btn-primary" disabled={fleet.loading || !!fleet.error || !fleet.vehicles.some(vehicle => vehicle.active)} onClick={fleet.openTripForm}><Plus size={16} />Tạo chuyến mới</button>}
      </div>
      {activeTab === 'trips' && !fleet.loading && !fleet.vehicles.some(vehicle => vehicle.active) && <p className="fleet-prerequisite">Thêm ít nhất một xe đang sử dụng ở mục Phương tiện.</p>}
    </div>
    {screen.kind === 'vehicle-form' && <VehicleEditor key={screen.vehicle?.id ?? 'new'} vehicle={screen.vehicle} drivers={fleet.drivers} busy={fleet.busy} error={fleet.error}
      onSave={async (input, id) => { const saved = await fleet.saveVehicle(input, id); if (saved) { setQuery(''); setVehicleStatus('active'); } return saved; }} onClose={fleet.close} />}
    {screen.kind === 'driver-form' && <DriverEditor key={screen.driver?.id ?? 'new'} driver={screen.driver} busy={fleet.busy} error={fleet.error}
      onSave={async (input, id) => { const saved = await fleet.saveDriver(input, id); if (saved) { setQuery(''); setDriverStatus('active'); } return saved; }} onClose={fleet.close} />}
    {screen.kind === 'trip-form' && <TripEditor vehicles={fleet.vehicles} drivers={fleet.drivers} initialVehicleId={screen.vehicleId} busy={fleet.busy} error={fleet.error} onSave={fleet.saveTrip} onClose={fleet.close} onManageRoutes={onManageRoutes} />}
    {screen.kind === 'trip-detail' && <TripDetailPanel key={`${screen.id}:${fleet.detail?.trip.attemptNumber ?? 'loading'}`} detail={fleet.detail} loading={fleet.loadingDetail} busy={fleet.busy} error={fleet.error} onClose={fleet.close}
      drivers={fleet.drivers} onRetry={() => void fleet.selectTrip(screen.id)} onAction={fleet.transition} onUpdateSchedule={fleet.updateTripSchedule} onUpdateDriver={fleet.updateTripDriver} onDeleteTrip={fleet.removeTrip} onFocusStop={onFocusStop} onSimulate={onSimulateTrip} liveSnapshot={liveSnapshot} />}
    {deactivate && <FleetConfirmDialog title={`Ngừng sử dụng xe ${deactivate.plateNumber}?`} message="Các chuyến chưa kết thúc phải được hoàn thành hoặc hủy trước. Lịch sử xe và chuyến đi vẫn được lưu."
      confirmLabel="Xác nhận ngừng sử dụng xe" busy={fleet.busy} error={fleet.error} onClose={() => setDeactivate(null)}
      onConfirm={() => { void fleet.removeVehicle(deactivate).then(success => { if (success) setDeactivate(null); }); }} />}
    {deactivateDriver && <FleetConfirmDialog title={`Ngừng tài xế ${deactivateDriver.fullName}?`} message="Tài xế phải được bỏ gán khỏi xe và các chuyến chưa kết thúc. Lịch sử chuyến đã hoàn thành vẫn được giữ."
      confirmLabel="Xác nhận ngừng tài xế" busy={fleet.busy} error={fleet.error} onClose={() => setDeactivateDriver(null)}
      onConfirm={() => { void fleet.removeDriver(deactivateDriver).then(success => { if (success) setDeactivateDriver(null); }); }} />}
  </div>;
}
