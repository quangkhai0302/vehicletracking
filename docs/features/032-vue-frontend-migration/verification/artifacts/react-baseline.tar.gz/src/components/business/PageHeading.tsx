import type { ReactNode } from 'react';

export function PageHeading({ eyebrow, title, description, actions }: {
  eyebrow: string;
  title: string;
  description: string;
  actions?: ReactNode;
}) {
  return <header className="page-heading">
    <div className="page-heading-copy"><span className="page-eyebrow">{eyebrow}</span><h2>{title}</h2><p>{description}</p></div>
    {actions && <div className="page-heading-actions">{actions}</div>}
  </header>;
}
