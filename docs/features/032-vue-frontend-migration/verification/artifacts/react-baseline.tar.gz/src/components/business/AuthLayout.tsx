import type { ReactNode } from 'react';
import { CalendarClock, Navigation, Route, ShieldCheck } from 'lucide-react';

export function AuthLayout({ children }: { children: ReactNode }) {
  return <main className="auth-page business-ui">
    <aside className="auth-introduction">
      <div className="auth-product-brand"><span><Navigation size={24} /></span><div><strong>Vehicle Tracking</strong><small>QUẢN LÝ VẬN HÀNH</small></div></div>
      <div className="auth-product-copy"><span className="auth-product-eyebrow">KẾT NỐI MỌI HÀNH TRÌNH</span><h2>Một không gian.<br /> Toàn bộ đội xe.</h2><p>Từ lập lịch đến giám sát hành trình, chủ động quản lý mọi hoạt động vận tải của bạn.</p>
        <div className="auth-capabilities"><span><Route size={19} />Theo dõi hành trình</span><span><CalendarClock size={19} />Điều phối lịch chạy</span><span><ShieldCheck size={19} />Quản lý phân quyền</span></div>
      </div>
      <p className="auth-product-footer">Đồng hành cùng từng chuyến đi.</p>
    </aside>
    <div className="auth-form-pane"><section className="auth-card">{children}</section><p className="auth-pane-footer">Vehicle Tracking · Không gian quản lý vận hành</p></div>
  </main>;
}
