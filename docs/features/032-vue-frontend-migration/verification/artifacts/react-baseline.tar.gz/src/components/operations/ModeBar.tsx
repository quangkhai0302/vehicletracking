import { Bell, BookOpen, BusFront, Navigation, Play, Route, Radio } from 'lucide-react';
import type { WorkspaceMode } from '../../types/workspace';

interface ModeBarProps {
  mode: WorkspaceMode;
  onChange: (mode: WorkspaceMode) => void;
  connectionLabel?: string;
  embedded?: boolean;
  alertCount?: number | null;
  alertsOpen?: boolean;
  onOpenAlerts?: () => void;
}

export function ModeBar({ mode, onChange, connectionLabel = 'Chưa có vị trí xe', embedded = false, alertCount = null, alertsOpen = false, onOpenAlerts }: ModeBarProps) {
  return <header className={`mode-bar glass-panel${embedded ? ' mode-bar-embedded' : ''}`} data-map-edge="top">
    <a className="canvas-brand" href="#main-map" aria-label="Vehicletracking · đến bản đồ">
      <span className="brand-logo-icon"><Navigation size={17} /></span>
      <span>vehicle<span>tracking</span><span className="brand-badge">OPS</span></span>
    </a>
    <nav aria-label="Chế độ vận hành">
      <button aria-pressed={mode === 'tracking'} onClick={() => onChange('tracking')}><BusFront size={16} /><span>Theo dõi</span></button>
      <button aria-pressed={mode === 'routes' || mode === 'stations'} onClick={() => onChange('routes')}><Route size={16} /><span>Tuyến & trạm</span></button>
      <button aria-pressed={mode === 'simulation'} onClick={() => onChange('simulation')}><Play size={16} /><span>Mô phỏng</span></button>
    </nav>
    <a className="guide-link" href="/huong-dan/index.html" target="_blank" rel="noreferrer" aria-label="Mở hướng dẫn sử dụng" title="Hướng dẫn sử dụng"><BookOpen size={15} /><span>Hướng dẫn</span></a>
    <button className="mode-alert-trigger" type="button" onClick={onOpenAlerts} aria-label={alertCount !== null && alertCount > 0 ? `Mở cảnh báo, ${alertCount} chưa đọc` : 'Mở thông báo vận hành'} aria-controls="operations-alert-drawer" aria-expanded={alertsOpen} aria-pressed={alertsOpen}>
      <Bell size={15} /><span>Cảnh báo</span>{alertCount !== null && alertCount > 0 && <b>{alertCount > 99 ? '99+' : alertCount}</b>}
    </button>
    <span className="connection-state"><span className="live-beacon-dot" aria-hidden="true" /><Radio size={13} /> <span>{connectionLabel}</span></span>
  </header>;
}
