import { ArrowUpRight, CarFront, Edit3, SearchX, Trash2, UserRound } from 'lucide-react';
import type { Driver, FleetVehicle, TripSummary } from '../../types/fleet';
import { TRIP_STATUS_LABELS, vehicleTypeLabel } from '../../types/fleet';
import type { FleetTab } from '../../hooks/useFleetWorkspace';
import { displayTripTime } from '../../utils/tripTime';

interface Props {
  tab: FleetTab;
  vehicles: FleetVehicle[];
  allVehicles: FleetVehicle[];
  drivers: Driver[];
  trips: TripSummary[];
  onEditVehicle: (vehicle: FleetVehicle) => void;
  onDeactivateVehicle: (vehicle: FleetVehicle) => void;
  onVehicleTrips: (id: number) => void;
  onEditDriver: (driver: Driver) => void;
  onDeactivateDriver: (driver: Driver) => void;
  onTrip: (id: number) => void;
}

function Status({ active }: { active: boolean }) {
  return <span className={`business-status ${active ? 'success' : 'neutral'}`}><i aria-hidden="true" />{active ? 'Đang hoạt động' : 'Đã ngừng hoạt động'}</span>;
}

export function FleetManagementTable(props: Props) {
  const { tab, vehicles, allVehicles, drivers, trips } = props;
  const count = tab === 'vehicles' ? vehicles.length : tab === 'drivers' ? drivers.length : trips.length;
  if (!count) return <div className="business-empty"><SearchX size={32} /><h3>Chưa có dữ liệu phù hợp</h3><p>Thử thay đổi bộ lọc hoặc thêm bản ghi mới để bắt đầu.</p></div>;

  return <div className="management-table-wrap"><table className="management-table">
    <caption className="business-sr-only">{tab === 'vehicles' ? 'Danh sách phương tiện' : tab === 'drivers' ? 'Danh sách tài xế' : 'Danh sách chuyến đi'}</caption>
    <thead><tr>{(tab === 'vehicles' ? ['Phương tiện', 'Loại xe', 'Tài xế phụ trách', 'Trạng thái', 'Thao tác']
      : tab === 'drivers' ? ['Tài xế', 'Giấy phép lái xe', 'Phương tiện', 'Trạng thái', 'Thao tác']
        : ['Chuyến đi / Tuyến', 'Phân công', 'Khởi hành', 'Trạng thái', 'Thao tác']).map(label => <th key={label} scope="col">{label}</th>)}</tr></thead>
    <tbody>
      {tab === 'vehicles' && vehicles.map(vehicle => <tr key={vehicle.id}>
        <td data-label="Phương tiện"><div className="management-identity"><span className="management-avatar"><CarFront size={21} /></span><div><strong>{vehicle.plateNumber}</strong><small>{vehicle.name}</small></div></div></td>
        <td data-label="Loại xe">{vehicleTypeLabel(vehicle.vehicleType)}</td>
        <td data-label="Tài xế phụ trách">{vehicle.driver?.fullName ?? <span className="business-unassigned">Chưa phân công</span>}</td>
        <td data-label="Trạng thái"><Status active={vehicle.active} /></td>
        <td data-label="Thao tác"><div className="management-row-actions"><button title="Xem chuyến đi" aria-label={`Xem chuyến xe ${vehicle.plateNumber}`} onClick={() => props.onVehicleTrips(vehicle.id)}><ArrowUpRight size={17} /></button>{vehicle.active && <><button aria-label={`Sửa xe ${vehicle.plateNumber}`} onClick={() => props.onEditVehicle(vehicle)}><Edit3 size={16} /></button><button className="danger" aria-label={`Ngừng sử dụng xe ${vehicle.plateNumber}`} onClick={() => props.onDeactivateVehicle(vehicle)}><Trash2 size={16} /></button></>}</div></td>
      </tr>)}
      {tab === 'drivers' && drivers.map(driver => {
        const vehicle = allVehicles.find(item => item.active && item.driver?.id === driver.id);
        return <tr key={driver.id}>
          <td data-label="Tài xế"><div className="management-identity"><span className="management-avatar person"><UserRound size={20} /></span><div><strong>{driver.fullName}</strong><small>{driver.phoneNumber}</small></div></div></td>
          <td data-label="Giấy phép lái xe"><span className="management-code">{driver.licenseNumber}</span></td>
          <td data-label="Phương tiện">{vehicle?.plateNumber ?? <span className="business-unassigned">Chưa phân công</span>}</td>
          <td data-label="Trạng thái"><Status active={driver.active} /></td>
          <td data-label="Thao tác"><div className="management-row-actions">{driver.active ? <><button aria-label={`Sửa tài xế ${driver.fullName}`} onClick={() => props.onEditDriver(driver)}><Edit3 size={16} /></button><button className="danger" aria-label={`Ngừng tài xế ${driver.fullName}`} onClick={() => props.onDeactivateDriver(driver)}><Trash2 size={16} /></button></> : <span>—</span>}</div></td>
        </tr>;
      })}
      {tab === 'trips' && trips.map(trip => <tr key={trip.id}>
        <td data-label="Chuyến đi / Tuyến"><div className="management-trip"><span className="management-code">#{trip.id}</span><strong>{trip.routeName}</strong></div></td>
        <td data-label="Phân công"><div className="management-stacked"><strong>{trip.vehiclePlateNumber}</strong><small>{trip.driver?.fullName ?? 'Chưa gán tài xế'}</small></div></td>
        <td data-label="Khởi hành"><time dateTime={trip.scheduledDepartureAt}>{displayTripTime(trip.scheduledDepartureAt)}</time></td>
        <td data-label="Trạng thái"><span className={`business-status ${trip.status.toLowerCase()}`}><i aria-hidden="true" />{TRIP_STATUS_LABELS[trip.status]}</span></td>
        <td data-label="Thao tác"><button className="management-detail-button" aria-label={`Mở chi tiết chuyến ${trip.id}, ${trip.routeName}`} onClick={() => props.onTrip(trip.id)}>Chi tiết <ArrowUpRight size={15} /></button></td>
      </tr>)}
    </tbody>
  </table><div className="management-table-footer">Hiển thị {count} {tab === 'vehicles' ? 'phương tiện' : tab === 'drivers' ? 'tài xế' : 'chuyến đi'}</div></div>;
}
