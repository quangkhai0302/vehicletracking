import { useEffect, useRef, type ReactNode } from 'react';

/** Native modal provides focus trapping, Escape handling and focus restoration. */
export function SidePanel({ className, label, busy = false, onClose, children }: {
  className: string;
  label: string;
  busy?: boolean;
  onClose: () => void;
  children: ReactNode;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const opener = useRef<HTMLElement | null>(null);
  useEffect(() => {
    const dialog = ref.current;
    if (!opener.current && document.activeElement instanceof HTMLElement) opener.current = document.activeElement;
    dialog?.showModal();
    return () => {
      dialog?.close();
      // React may detach the dialog before effect cleanup, so restore explicitly.
      if (opener.current?.isConnected) opener.current.focus();
    };
  }, []);
  return <dialog ref={ref} className={`business-side-panel ${className}`} aria-label={label} onCancel={event => {
    event.preventDefault();
    if (!busy) onClose();
  }}>{children}</dialog>;
}
