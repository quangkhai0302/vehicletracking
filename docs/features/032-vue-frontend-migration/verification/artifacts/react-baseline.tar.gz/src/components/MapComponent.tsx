import { lazy, Suspense, useCallback, useEffect, useMemo, useRef, useState, type FC } from 'react';
import L from 'leaflet';
import { decodeFlexiblePolyline } from '../services/polyline';
import type { MapTheme } from '../types/map';
import type { TripDetail } from '../types/fleet';
import type { RouteDetail, RouteDraftStop, RouteStopRole } from '../types/route';
import { useLiveOperations } from '../hooks/useLiveOperations';
import { useSimulator } from '../hooks/useSimulator';
import { useSimulationFleet } from '../hooks/useSimulationFleet';
import { usePlannedVehicleAnchors } from '../hooks/usePlannedVehicleAnchors';
import { useVehicleMarkers, type VehicleMarkerAnchor } from '../hooks/useVehicleMarkers';
import { useSelectedVehicleRoute } from '../hooks/useSelectedVehicleRoute';
import { makeMotionPath, type MotionPath } from '../utils/vehicleMotion';
import type { WorkspaceMode } from '../types/workspace';
import { MapControls } from './MapControls';
import { StationDrawer } from './StationDrawer';
import { StationPanel } from './StationPanel';
import { FleetWorkspace } from './fleet/FleetWorkspace';
import { RouteWorkspace } from './route/RouteWorkspace';
import './route/route.css';
import { Bell, ChevronDown, ChevronUp, Crosshair, List, PanelLeftClose, Play, X } from 'lucide-react';
import { useMapCamera } from '../hooks/useMapCamera';
import { useStationWorkspace } from '../hooks/useStationWorkspace';
import { useCompactLayout } from '../hooks/useCompactLayout';
import { ModeBar } from './operations/ModeBar';
import { SimulatorPanel } from './operations/SimulatorPanel';
import { TripTrafficSummary } from './operations/TripTrafficSummary';
import { AlertStream } from './operations/AlertStream';
import { ConfirmStationDelete } from './operations/ConfirmStationDelete';
import { useTraffic } from '../hooks/useTraffic';
import { TrafficLayer } from './traffic/TrafficLayer';

const RouteInspectionLayer = lazy(() => import('./route/RouteInspectionLayer').then(module => ({ default: module.RouteInspectionLayer })));
const SimulationFleetLayer = lazy(() => import('./operations/SimulationFleetLayer').then(module => ({ default: module.SimulationFleetLayer })));
const SimulationRoutesLayer = lazy(() => import('./operations/SimulationRoutesLayer').then(module => ({ default: module.SimulationRoutesLayer })));

const HCMC_CENTER: [number, number] = [10.7769, 106.7009];

function createRouteStopIcon(sequenceNumber: number, role: RouteStopRole): L.DivIcon {
  const roleClass = role.toLowerCase();
  return L.divIcon({
    className: 'route-stop-div-icon',
    html: `<div class="route-stop-map-marker ${roleClass}">${sequenceNumber}</div>`,
    iconSize: [28, 28],
    iconAnchor: [14, 14],
    popupAnchor: [0, -16],
    tooltipAnchor: [0, -14],
  });
}

function createStationIcon(state: 'default' | 'selected' | 'muted' | 'draft'): L.DivIcon {
  return L.divIcon({
    className: 'station-div-icon',
    html: `<span class="station-map-marker ${state}"><span class="station-map-marker-core"></span></span>`,
    iconSize: [34, 42],
    iconAnchor: [17, 38],
    popupAnchor: [0, -36],
    tooltipAnchor: [0, -32],
  });
}

function validCoordinate(value: string, min: number, max: number): number | null {
  if (!value.trim()) return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed >= min && parsed <= max ? parsed : null;
}

export interface MapComponentProps {
  initialWorkspace?: WorkspaceMode;
  initialTripId?: number | null;
  embedded?: boolean;
  onWorkspaceChange?: (workspace: WorkspaceMode) => void;
}

export const MapComponent: FC<MapComponentProps> = ({ initialWorkspace = 'tracking', initialTripId = null, embedded = false, onWorkspaceChange }) => {
  const rootRef = useRef<HTMLElement>(null);
  const [workspace, setWorkspace] = useState<WorkspaceMode>(initialWorkspace);
  const compact = useCompactLayout();
  const [activePanel, setActivePanel] = useState<'context' | 'simulator' | 'alerts' | null>('context');
  const [drawerOpen, setDrawerOpen] = useState(true);
  const [sheetExpanded, setSheetExpanded] = useState(false);
  const [simulatorExpanded, setSimulatorExpanded] = useState(true);
  const [alertsOpen, setAlertsOpen] = useState(false);
  const alertOpenerRef = useRef<'mode' | 'launcher'>('mode');
  const alertPreviousPanelRef = useRef<'context' | 'simulator' | null>(null);
  const alertCloseButtonRef = useRef<HTMLButtonElement>(null);
  const [alertUnreadOverride, setAlertUnreadOverride] = useState<{ serverTime: string; count: number } | null>(null);
  const [showStations, setShowStations] = useState(true);
  const [showRoutes, setShowRoutes] = useState(true);
  const [showTraffic, setShowTraffic] = useState(true);
  const [draftStops, setDraftStops] = useState<RouteDraftStop[]>([]);
  const [selectedDraftStopId, setSelectedDraftStopId] = useState<string | null>(null);
  useEffect(() => {
    // The map stays mounted while the URL changes so an active simulator trip is preserved.
    // oxlint-disable-next-line react/set-state-in-effect
    setWorkspace(initialWorkspace);
    // oxlint-disable-next-line react/set-state-in-effect
    setActivePanel(initialWorkspace === 'simulation' ? 'simulator' : 'context');
    if (initialWorkspace === 'simulation') {
      // oxlint-disable-next-line react/set-state-in-effect
      setSimulatorExpanded(true);
    }
  }, [initialWorkspace]);
  const routeDraftLayerRef = useRef<L.LayerGroup | null>(null);
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const [mapReady, setMapReady] = useState(false);
  const tileLayerRef = useRef<L.TileLayer | null>(null);
  const stationLayerRef = useRef<L.LayerGroup | null>(null);
  const draftLayerRef = useRef<L.LayerGroup | null>(null);
  const routeLayerRef = useRef<L.LayerGroup | null>(null);
  const plannedRouteLayerRef = useRef<L.LayerGroup | null>(null);
  const plannedRouteBoundsRef = useRef<L.LatLngBounds | null>(null);
  const stationMarkerRef = useRef<Map<number, L.Marker>>(new Map());

  const [theme, setTheme] = useState<MapTheme>('google-roadmap');
  const [toast, setToast] = useState<string | null>(null);
  const live = useLiveOperations();
  const simulator = useSimulator(live.snapshot, setToast);
  const { busy: simulatorBusy, select: selectSimulatorTrip } = simulator;
  const simulationFleet = useSimulationFleet(live.snapshot, workspace === 'simulation');
  const persistedVehicleAnchors = usePlannedVehicleAnchors(live.snapshot);
  const traffic = useTraffic(mapInstanceRef, showTraffic, mapReady);
  const trafficStatus = traffic.flow?.status ?? traffic.incidents?.status;
  const trafficMessage = traffic.loading
    ? 'Đang tải giao thông…'
    : traffic.error ? 'Chưa tải được giao thông. Thử lại trong lớp bản đồ.' : (trafficStatus === 'STALE' ? 'Đang dùng dữ liệu gần nhất.'
      : trafficStatus === 'UNAVAILABLE' ? 'Giao thông chưa khả dụng.'
        : showTraffic ? 'Đang hiển thị dữ liệu theo nguồn của tuyến/khu vực'
          : 'Tạm tắt');
  const connectionLabel = live.connection === 'live' ? 'Đang cập nhật trực tiếp' : live.connection === 'connecting' ? 'Đang kết nối…' : 'Mất kết nối · Đang thử lại';
  const { focusLocation, fitBounds, getVisibleCenter, releaseFocus } = useMapCamera(rootRef, mapInstanceRef);
  const [routeRefreshToken, setRouteRefreshToken] = useState(0);
  const stationWorkspace = useStationWorkspace({
    focusLocation, onToast: setToast,
    onStationUpdated: () => setRouteRefreshToken(current => current + 1),
    onPickStart: () => setActivePanel(null),
    onPickEnd: () => { setDrawerOpen(true); setActivePanel('context'); },
  });
  const {
    stations, loadingStations, savingStation, deletingStation, stationError, selectedStationId,
    formMode, editingStation, stationForm, pickingLocation, deleteCandidate, selectedStation,
    setStationForm, setPickingLocation, setSelectedStationId, setStationError, setDeleteCandidate,
    handleBeginCreate, handleSelectStation, handleBeginEdit, handleCloseStationDrawer,
    handleSaveStation, handleFieldChange, handleDeactivate,
  } = stationWorkspace;
  const contextVisible = drawerOpen && !(pickingLocation && workspace === 'stations') && (!compact || activePanel === 'context');
  const snapshotUnreadAlertCount = live.snapshot ? live.snapshot.notifications.filter(item => !item.readAt).length : null;
  const reportUnreadAlertCount = useCallback((count: number) => {
    if (!live.snapshot) return;
    setAlertUnreadOverride({ serverTime: live.snapshot.serverTime, count });
  }, [live.snapshot]);
  const liveUnreadOverride = live.snapshot && alertUnreadOverride?.serverTime === live.snapshot.serverTime ? alertUnreadOverride.count : null;
  const unreadAlertCount = snapshotUnreadAlertCount === null ? null : liveUnreadOverride ?? snapshotUnreadAlertCount;
  const closeAlerts = useCallback(() => {
    setAlertsOpen(false);
    setActivePanel(compact ? alertPreviousPanelRef.current : 'context');
    const selector = alertOpenerRef.current === 'launcher' ? '.panel-alert-launcher' : '.mode-alert-trigger';
    window.requestAnimationFrame(() => rootRef.current?.querySelector<HTMLButtonElement>(selector)?.focus());
  }, [compact]);
  // URL-driven selection intentionally synchronizes map state after the live snapshot arrives.
  // oxlint-disable-next-line react/set-state-in-effect
  useEffect(() => {
    if (!alertsOpen) return;
    window.requestAnimationFrame(() => alertCloseButtonRef.current?.focus());
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && !(event.target instanceof HTMLElement && event.target.closest('dialog'))) closeAlerts();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [alertsOpen, closeAlerts]);
  const selectMode = (mode: WorkspaceMode) => {
    if (mode !== 'stations') setPickingLocation(false);
    setAlertsOpen(false);
    setWorkspace(mode);
    onWorkspaceChange?.(mode);
    setSheetExpanded(false);
    setDrawerOpen(true);
    setActivePanel(mode === 'simulation' ? 'simulator' : 'context');
    if (mode === 'simulation') setSimulatorExpanded(true);
  };
  const openPanel = (panel: 'context' | 'simulator' | 'alerts') => {
    const previousPanel = activePanel;
    setPickingLocation(false);
    setActivePanel(panel);
    setSheetExpanded(false);
    if (panel !== 'alerts') setAlertsOpen(false);
    if (panel === 'context') { setDrawerOpen(true); setPickingLocation(false); }
    if (panel === 'simulator') setSimulatorExpanded(true);
    if (panel === 'alerts') {
      if (!alertsOpen) alertPreviousPanelRef.current = previousPanel === 'context' || previousPanel === 'simulator' ? previousPanel : null;
      setAlertsOpen(true); setSheetExpanded(false);
    }
  };

  // Route Planning Display State (Data flow managed by RouteWorkspace)
  const [editorRoute, setPlannedRoute] = useState<RouteDetail | null>(null);
  const [createdVehicleAnchors, setCreatedVehicleAnchors] = useState<VehicleMarkerAnchor[]>([]);
  const handleTripCreated = useCallback((detail: TripDetail) => {
    const start = [...detail.stops].sort((a, b) => a.sequenceNumber - b.sequenceNumber)[0];
    if (!start || !Number.isFinite(start.latitude) || !Number.isFinite(start.longitude)) {
      setToast('Chuyến đã tạo nhưng chưa có tọa độ trạm đầu để hiển thị xe.');
      return;
    }
    setCreatedVehicleAnchors(current => [
      ...current.filter(anchor => anchor.vehicleId !== detail.trip.vehicleId && anchor.tripId !== detail.trip.id),
      {
        vehicleId: detail.trip.vehicleId,
        tripId: detail.trip.id,
        vehiclePlateNumber: detail.trip.vehiclePlateNumber,
        vehicleType: detail.trip.vehicleType,
        latitude: start.latitude,
        longitude: start.longitude,
      },
    ]);
    focusLocation([start.latitude, start.longitude], 16);
  }, [focusLocation]);

  const [selectedVehicleId, setSelectedVehicleId] = useState<number | null>(null);
  const [tripSelection, setTripSelection] = useState<{ tripId: number | null } | null>(null);
  const [followingVehicle, setFollowingVehicle] = useState(false);
  const initialTripAppliedRef = useRef<number | null>(null);
  const plannedVehicleAnchors = useMemo(() => {
    const byVehicle = new Map<number, VehicleMarkerAnchor>();
    persistedVehicleAnchors.forEach(anchor => byVehicle.set(anchor.vehicleId, anchor));
    createdVehicleAnchors.forEach(anchor => {
      const trip = live.snapshot?.trips.find(item => item.id === anchor.tripId);
      if (!trip || (trip.status !== 'COMPLETED' && trip.status !== 'CANCELLED')) byVehicle.set(anchor.vehicleId, anchor);
    });
    return [...byVehicle.values()];
  }, [persistedVehicleAnchors, createdVehicleAnchors, live.snapshot]);
  const mapSnapshot = useMemo(() => {
    if (!live.snapshot || workspace !== 'simulation') return live.snapshot;
    const waitingIds = new Set(simulationFleet.previews.map(item=>item.trip.vehicleId));
    const fleetTripIds = new Set(simulationFleet.trips.map(trip=>trip.id));
    return {...live.snapshot, positions:live.snapshot.positions.filter(point=>!waitingIds.has(point.vehicleId)
      && (point.source!=='SIMULATOR' || fleetTripIds.has(point.tripId)))};
  }, [live.snapshot,workspace,simulationFleet.previews,simulationFleet.trips]);
  const selectedVehicle = useMemo(
    () => mapSnapshot?.positions.find(point => point.vehicleId === selectedVehicleId
      && (!tripSelection?.tripId || point.tripId === tripSelection.tripId)) ?? null,
    [selectedVehicleId, mapSnapshot, tripSelection]
  );
  const markerAnchors = useMemo(
    () => workspace === 'simulation'
      ? plannedVehicleAnchors.filter(anchor => !simulationFleet.previews.some(item => item.trip.id === anchor.tripId))
      : plannedVehicleAnchors,
    [workspace, plannedVehicleAnchors, simulationFleet.previews]
  );
  const selectedPlannedVehicle = plannedVehicleAnchors.find(anchor => anchor.vehicleId === selectedVehicleId
    && (!tripSelection?.tripId || anchor.tripId === tripSelection.tripId)) ?? null;
  const selectedWaitingVehicle = simulationFleet.previews.find(item => item.trip.vehicleId === selectedVehicleId
    && (!tripSelection?.tripId || item.trip.id === tripSelection.tripId));
  const selectedTripId = (selectedVehicleId !== null ? tripSelection?.tripId : null) ?? selectedVehicle?.tripId
    ?? (selectedVehicleId === null ? null : selectedPlannedVehicle?.tripId ?? selectedWaitingVehicle?.trip.id
      ?? (simulator.trip?.vehicleId === selectedVehicleId ? simulator.trip.id : null));
  const selectedRun = live.snapshot?.simulations.find(run => run.tripId === selectedTripId);
  const vehicleRoute = useSelectedVehicleRoute(selectedTripId, setToast, `${selectedRun?.attemptNumber ?? 1}:${selectedRun?.routeRevisionId ?? 0}`);
  const plannedRoute = workspace === 'routes' ? editorRoute : workspace === 'stations' ? null : vehicleRoute;
  const selectedSimulationRoutes = simulationFleet.routes.filter(item => item.trip.id === selectedTripId);
  const motionPaths = useMemo(() => {
    const paths = new Map<number, MotionPath>();
    for (const item of simulationFleet.routes) paths.set(item.trip.id, makeMotionPath(item.segments));
    if (selectedTripId !== null && vehicleRoute) {
      try { paths.set(selectedTripId, makeMotionPath(vehicleRoute.sections.map(section => decodeFlexiblePolyline(section.encodedPolyline)))); }
      catch { /* Invalid geometry cannot be used for presentation interpolation. */ }
    }
    return paths;
  }, [simulationFleet.routes, selectedTripId, vehicleRoute]);
  const hasSimulationRoute = workspace === 'simulation' && selectedSimulationRoutes.length > 0;
  const selectVehicleTrip = useCallback((vehicleId: number, tripId: number) => {
    if (simulatorBusy) return;
    setSelectedVehicleId(vehicleId);
    setTripSelection({ tripId });
    selectSimulatorTrip(tripId);
    setFollowingVehicle(false);
    if (workspace === 'routes' || workspace === 'stations') {
      setWorkspace('tracking'); onWorkspaceChange?.('tracking'); setPickingLocation(false);
    }
    setDrawerOpen(true); setSimulatorExpanded(true);
    setSheetExpanded(true);
    setActivePanel('context');
  }, [onWorkspaceChange, selectSimulatorTrip, setPickingLocation, simulatorBusy, workspace]);
  // URL-driven selection intentionally synchronizes map state after the live snapshot arrives.
  useEffect(() => {
    if (initialTripId === null) {
      initialTripAppliedRef.current = null;
      return;
    }
    if (initialTripAppliedRef.current === initialTripId || !live.snapshot || simulatorBusy) return;
    const trip = live.snapshot.trips.find(item => item.id === initialTripId);
    if (!trip) return;
    initialTripAppliedRef.current = initialTripId;
    // oxlint-disable-next-line react/set-state-in-effect
    selectVehicleTrip(trip.vehicleId, trip.id);
    const point = live.snapshot.positions.find(item => item.tripId === trip.id);
    if (point) focusLocation([point.latitude, point.longitude], 16);
  }, [initialTripId, live.snapshot, simulatorBusy, focusLocation, selectVehicleTrip]);
  const clearVehicleSelection = () => {
    if (simulator.busy) return;
    setSelectedVehicleId(null); setFollowingVehicle(false);
    setTripSelection({ tripId: null }); simulator.select(null);
  };
  useVehicleMarkers({ mapRef: mapInstanceRef, snapshot: mapSnapshot, now: live.now,
    motionPaths,
    plannedPositions: markerAnchors, visible: true, selectedId: selectedVehicleId, groupSelection: workspace==='simulation',
    following: followingVehicle, onSelect: selectVehicleTrip, onFocus: focusLocation });

  const focusVehicle = (id: number) => {
    const planned = plannedVehicleAnchors.find(item => item.vehicleId === id);
    const actual = mapSnapshot?.positions.find(item => item.vehicleId === id);
    const point = planned && actual?.tripId !== planned.tripId ? planned : actual ?? planned;
    if (point && !simulator.busy) {
      selectVehicleTrip(id, point.tripId); focusLocation([point.latitude,point.longitude],16);
    }
  };
  const openSimulation = (id: number) => {
    const trip = live.snapshot?.trips.find(item => item.id === id);
    if (simulator.busy) return;
    if (trip) selectVehicleTrip(trip.vehicleId, id);
    else { setSelectedVehicleId(null); setTripSelection({ tripId: id }); simulator.select(id); }
    selectMode('simulation');
  };
  const selectSimulationVehicle = (tripId: number) => {
    if (simulator.busy) return;
    const preview = simulationFleet.previews.find(item=>item.trip.id===tripId);
    const trip = preview?.trip ?? live.snapshot?.trips.find(item=>item.id===tripId);
    if (!trip) return;
    selectVehicleTrip(trip.vehicleId, tripId);
    setWorkspace('simulation'); onWorkspaceChange?.('simulation'); setActivePanel('simulator');
    const point = live.snapshot?.positions.find(item => item.tripId === tripId);
    if (preview) focusLocation([preview.start.latitude,preview.start.longitude],16);
    else if (point) focusLocation([point.latitude,point.longitude],16);
  };
  const fleetPoints: [number,number][] = [
    ...(showRoutes ? selectedSimulationRoutes.flatMap(item=>item.segments.flat()) : []),
    ...simulationFleet.previews.map(item=>[item.start.latitude,item.start.longitude] as [number,number]),
    ...(mapSnapshot?.positions.filter(point=>simulationFleet.trips.some(trip=>trip.id===point.tripId))
      .map(point=>[point.latitude,point.longitude] as [number,number]) ?? []),
  ];
  const fleetPointsKey = JSON.stringify(fleetPoints);
  const fleetFitted = useRef(false);
  useEffect(() => {
    if (workspace !== 'simulation') { fleetFitted.current=false; return; }
    if (!mapReady || simulationFleet.loading || fleetFitted.current || fleetPointsKey==='[]') return;
    fleetFitted.current=true;
    fitBounds(L.latLngBounds(JSON.parse(fleetPointsKey) as [number,number][]));
  }, [workspace,mapReady,simulationFleet.loading,fleetPointsKey,fitBounds]);
  const fitSimulationFleet = () => { if (fleetPoints.length) { setFollowingVehicle(false); fitBounds(L.latLngBounds(fleetPoints)); } };

  // Auto hide toast
  useEffect(() => {
    if (!toast) return;
    const timeoutId = window.setTimeout(() => setToast(null), 3500);
    return () => window.clearTimeout(timeoutId);
  }, [toast]);

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current || mapInstanceRef.current) return;

    const map = L.map(mapContainerRef.current, {
      center: HCMC_CENTER,
      zoom: 13,
      zoomControl: false,
      preferCanvas: true,
      zoomSnap: 1,
      zoomDelta: 1,
      wheelPxPerZoomLevel: 120,
      inertia: true,
      inertiaDeceleration: 3400,
      inertiaMaxSpeed: 2000,
    });

    const trafficPane = map.createPane('trafficPane');
    trafficPane.style.zIndex = '350';

    const routePane = map.createPane('routePane');
    routePane.style.zIndex = '450';

    routeDraftLayerRef.current = L.layerGroup().addTo(map);

    routeLayerRef.current = L.layerGroup().addTo(map);
    plannedRouteLayerRef.current = L.layerGroup().addTo(map);
    stationLayerRef.current = L.layerGroup().addTo(map);
    draftLayerRef.current = L.layerGroup().addTo(map);

    // User drag starts -> Stop following vehicle
    const onDragStart = () => {
      setFollowingVehicle(false);
      releaseFocus();
    };

    map.on('dragstart', onDragStart);
    mapInstanceRef.current = map;
    setMapReady(true);

    return () => {
      map.off('dragstart', onDragStart);
      map.remove();
      mapInstanceRef.current = null;
      setMapReady(false);
      stationLayerRef.current = null;
      draftLayerRef.current = null;
      routeLayerRef.current = null;
      plannedRouteLayerRef.current = null;
      routeDraftLayerRef.current = null;
    };
  }, [releaseFocus]);

  // Map click for picking location
  useEffect(() => {
    const map = mapInstanceRef.current;
    const mapContainer = mapContainerRef.current;
    if (!map || workspace !== 'stations' || formMode === 'closed' || !pickingLocation) return;

    const onMapClick = (event: L.LeafletMouseEvent) => {
      setStationForm((current) => ({
        ...current,
        latitude: event.latlng.lat.toFixed(6),
        longitude: event.latlng.lng.toFixed(6),
      }));
      setPickingLocation(false);
      setDrawerOpen(true); setActivePanel('context');
      focusLocation(event.latlng);
    };

    map.on('click', onMapClick);
    mapContainer?.classList.add('station-picking');
    return () => {
      map.off('click', onMapClick);
      mapContainer?.classList.remove('station-picking');
    };
  }, [formMode, pickingLocation, workspace, setStationForm, setPickingLocation, focusLocation]);

  // Render Stations Layer
  useEffect(() => {
    const layer = stationLayerRef.current;
    const map = mapInstanceRef.current;
    if (!layer || !map) return;
    layer.clearLayers();
    stationMarkerRef.current.clear();

    if (!showStations) return;
    stations.forEach((station) => {
      if (showRoutes && (plannedRoute?.stops.some(stop => stop.stationId === station.id) ||
        (workspace === 'routes' && draftStops.some(stop => stop.stationId === station.id)))) return;
      if (workspace === 'stations' && formMode === 'edit' && editingStation?.id === station.id) return;
      const selected = workspace === 'stations' && selectedStationId === station.id;
      const position: L.LatLngExpression = [station.latitude, station.longitude];

      if (selected) {
        L.circle(position, {
          radius: station.checkinRadiusMeters,
          color: '#22d3ee',
          weight: 2,
          opacity: 0.85,
          fillColor: '#38bdf8',
          fillOpacity: 0.12,
          interactive: false,
        }).addTo(layer);
      }

      const marker = L.marker(position, {
        icon: createStationIcon(workspace === 'tracking' ? 'muted' : selected ? 'selected' : 'default'),
        zIndexOffset: selected ? 500 : 100,
        bubblingMouseEvents: false,
      });

      // H-02: Use DOM node and textContent to prevent XSS in Leaflet tooltip
      const stationTooltip = document.createElement('span');
      stationTooltip.textContent = station.name;
      marker.bindTooltip(stationTooltip, { direction: 'top', offset: [0, -28], opacity: 0.9 });

      if (workspace === 'tracking') {
        marker.on('click', () => {
          focusLocation([station.latitude, station.longitude], 16);
        });
      } else {
        marker.on('click', () => {
          if (formMode !== 'closed') return;
          setSelectedStationId(station.id);
          setDrawerOpen(true); setActivePanel('context');
          setStationError(null);
          focusLocation([station.latitude, station.longitude], 16);
        });
      }

      marker.addTo(layer);
      stationMarkerRef.current.set(station.id, marker);
    });
  }, [editingStation?.id, formMode, selectedStationId, stations, workspace, showStations, focusLocation, setSelectedStationId, setStationError, showRoutes, plannedRoute, draftStops]);

  // Render Draft Station (Create/Edit)
  useEffect(() => {
    const layer = draftLayerRef.current;
    if (!layer) return;
    layer.clearLayers();
    if (workspace !== 'stations' || formMode === 'closed') return;

    const latitude = validCoordinate(stationForm.latitude, -90, 90);
    const longitude = validCoordinate(stationForm.longitude, -180, 180);
    if (latitude === null || longitude === null) return;
    const position: L.LatLngExpression = [latitude, longitude];
    const radius = Number(stationForm.checkinRadiusMeters);

    if (Number.isFinite(radius) && radius >= 10 && radius <= 1000) {
      L.circle(position, {
        radius,
        color: '#f59e0b',
        dashArray: '6 6',
        weight: 2,
        opacity: 0.9,
        fillColor: '#f59e0b',
        fillOpacity: 0.14,
        interactive: false,
      }).addTo(layer);
    }

    const marker = L.marker(position, {
      icon: createStationIcon('draft'),
      draggable: true,
      zIndexOffset: 1000,
      bubblingMouseEvents: false,
    });

    marker.on('dragend', () => {
      const coordinates = marker.getLatLng();
      setStationForm((current) => ({
        ...current,
        latitude: coordinates.lat.toFixed(6),
        longitude: coordinates.lng.toFixed(6),
      }));
      setPickingLocation(false);
    });

    marker.bindTooltip('Kéo để tinh chỉnh vị trí trạm', { permanent: true, direction: 'top', offset: [0, -28] });
    marker.addTo(layer);
  }, [formMode, stationForm, workspace, setStationForm, setPickingLocation]);

  // Google raster basemap is loaded directly by Leaflet without a Google API key.
  // Traffic, incidents, ETA and routing remain backed by HERE through our backend.
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map || !mapReady) return;

    if (tileLayerRef.current) {
      map.removeLayer(tileLayerRef.current);
      tileLayerRef.current = null;
    }
    const baseType = theme === 'google-satellite' ? 'y' : 'm';
    const layerType = showTraffic ? `${baseType},traffic` : baseType;
    const newTileLayer = L.tileLayer(
      `https://{s}.google.com/vt/lyrs=${layerType}&hl=vi&gl=VN&x={x}&y={y}&z={z}`,
      {
        maxZoom: 20,
        subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
        className: theme === 'google-dark' ? 'dark-map-tiles' : '',
        attribution: '&copy; Google Maps',
        updateWhenZooming: false,
        updateWhenIdle: true,
        keepBuffer: 4,
      }
    );

    // Auto-retry transient failed tiles (e.g. rate-limit or network timeout)
    newTileLayer.on('tileerror', (event) => {
      const tile = (event as L.TileEvent).tile as HTMLImageElement;
      if (!tile) return;
      const retryCount = Number(tile.dataset.retryCount || '0');
      if (retryCount < 2) {
        tile.dataset.retryCount = String(retryCount + 1);
        const originalSrc = tile.src;
        setTimeout(() => {
          tile.src = originalSrc;
        }, 600 * (retryCount + 1));
      }
    });
    newTileLayer.on('tileload', (event) => {
      const tile = (event as L.TileEvent).tile as HTMLImageElement;
      if (tile) delete tile.dataset.retryCount;
    });

    newTileLayer.addTo(map).bringToBack();
    tileLayerRef.current = newTileLayer;

    return () => {
      newTileLayer.off();
      if (map.hasLayer(newTileLayer)) map.removeLayer(newTileLayer);
      if (tileLayerRef.current === newTileLayer) {
        tileLayerRef.current = null;
      }
    };
  }, [theme, showTraffic, mapReady]);

  // Render Planned Route (Polyline & Stop markers)
  useEffect(() => {
    const layer = plannedRouteLayerRef.current;
    const map = mapInstanceRef.current;
    if (!layer || !map) return;

    layer.clearLayers();
    plannedRouteBoundsRef.current = null;

    if (!showRoutes || !plannedRoute) {
      return;
    }

    let toastTimer: number | null = null;
    let hasDecodeError = false;
    const allCoords: [number, number][] = [];
    const decodedSections: { coords: [number, number][]; section: RouteDetail['sections'][number] }[] = [];

    // M2-04: Decode polyline for each section. If ANY section fails or returns empty coordinates, fail the whole route!
    for (const section of plannedRoute.sections) {
      try {
        const coords = decodeFlexiblePolyline(section.encodedPolyline);
        if (coords.length === 0) {
          hasDecodeError = true;
          break;
        }
        decodedSections.push({ coords, section });
        allCoords.push(...coords);
      } catch {
        hasDecodeError = true;
        break;
      }
    }

    // If any section is broken, reject partial geometry: clear layer, don't draw markers, notify user
    if (hasDecodeError) {
      layer.clearLayers();
      toastTimer = window.setTimeout(() => {
        setToast('Lỗi: Hình học đường đi (polyline) của tuyến bị hỏng, không thể hiển thị lộ trình.');
      }, 0);
      return () => {
        if (toastTimer !== null) window.clearTimeout(toastTimer);
      };
    }

    if (allCoords.length > 0 && !hasSimulationRoute) {
      /*
       * Keep each HERE section as its own Leaflet path.  Concatenating
       * sections into one array creates a straight connector whenever HERE
       * rounds a via endpoint differently in adjacent sections; that
       * connector can visibly cut across buildings instead of following a
       * road.
       */
      for (const { coords: sectionCoords } of decodedSections) {
        // 1. Google Maps subtle route shadow (đổ bóng mỏng nhẹ giúp tách biệt trên mọi nền bản đồ)
        L.polyline(sectionCoords, {
          pane: 'routePane',
          color: 'rgba(24, 90, 188, 0.24)',
          weight: 10,
          opacity: 1,
          lineCap: 'round',
          lineJoin: 'round',
          interactive: false,
        }).addTo(layer);

        // 2. Google Maps outer casing (viền xanh đậm Google Blue 700 định hình đường đi sắc nét)
        L.polyline(sectionCoords, {
          pane: 'routePane',
          color: '#1967d2',
          weight: 7.5,
          opacity: 0.96,
          lineCap: 'round',
          lineJoin: 'round',
          interactive: false,
        }).addTo(layer);

        // 3. Google Maps inner core (lõi xanh Google Primary Blue rực rỡ đặc trưng của Google Maps)
        L.polyline(sectionCoords, {
          pane: 'routePane',
          color: '#4285f4',
          weight: 5,
          opacity: 1.0,
          lineCap: 'round',
          lineJoin: 'round',
          interactive: false,
        }).addTo(layer);

      }
    }

    // Draw numbered stop markers
    plannedRoute.stops.forEach((stop) => {
      const marker = L.marker([stop.latitude, stop.longitude], {
        icon: createRouteStopIcon(stop.sequenceNumber, stop.role),
        zIndexOffset: 700 + stop.sequenceNumber,
      });

      const roleName = stop.role === 'START' ? 'Khởi hành' : stop.role === 'END' ? 'Về đích' : 'Đón/trả';

      // H-02: Use DOM node and textContent to prevent XSS in Leaflet tooltip
      const tooltipContainer = document.createElement('div');
      const strongEl = document.createElement('strong');
      strongEl.textContent = `#${stop.sequenceNumber} - ${stop.stationName}`;
      tooltipContainer.appendChild(strongEl);
      tooltipContainer.appendChild(document.createTextNode(` (${roleName})`));
      tooltipContainer.appendChild(document.createElement('br'));
      tooltipContainer.appendChild(document.createTextNode(`Dừng: ${stop.dwellDurationSeconds}s`));

      marker.bindTooltip(tooltipContainer, { direction: 'top', offset: [0, -14], opacity: 0.95 });

      marker.addTo(layer);
    });

    // Fit bounds only when all sections decoded successfully
    if (allCoords.length > 0) {
      plannedRouteBoundsRef.current = L.latLngBounds(allCoords);
    }
    if (allCoords.length > 0 && workspace !== 'simulation' && mapContainerRef.current?.clientWidth) {
      map.invalidateSize({ pan: false });
      fitBounds(L.latLngBounds(allCoords));
    }

    return () => {
      if (toastTimer !== null) window.clearTimeout(toastTimer);
    };
  }, [plannedRoute, showRoutes, fitBounds, workspace, hasSimulationRoute]);

  // Draft markers communicate order only; the POST response supplies road geometry.
  useEffect(() => {
    const layer = routeDraftLayerRef.current;
    if (!layer) return;
    layer.clearLayers();
    if (workspace !== 'routes' || !showRoutes || plannedRoute) return;

    // Google Maps style draft connector line between draft stations
    const draftCoords: [number, number][] = [];
    draftStops.forEach((stop) => {
      const station = stations.find(item => item.id === stop.stationId && item.active);
      if (station) {
        draftCoords.push([station.latitude, station.longitude]);
      }
    });

    if (draftCoords.length >= 2) {
      // Draft Casing - Google Maps Style
      L.polyline(draftCoords, {
        pane: 'routePane',
        color: '#1967d2',
        weight: 6,
        opacity: 0.92,
        dashArray: '6, 8',
        lineCap: 'round',
        lineJoin: 'round',
        interactive: false,
      }).addTo(layer);

      // Draft Inner Google Blue
      L.polyline(draftCoords, {
        pane: 'routePane',
        color: '#4285f4',
        weight: 4,
        opacity: 1.0,
        dashArray: '6, 8',
        lineCap: 'round',
        lineJoin: 'round',
        interactive: false,
      }).addTo(layer);
    }

    draftStops.forEach((stop, index) => {
      const station = stations.find(item => item.id === stop.stationId && item.active);
      if (!station) return;
      const role = index === 0 ? 'START' : index === draftStops.length - 1 ? 'END' : 'STOP';
      const marker = L.marker([station.latitude, station.longitude], {
        icon: createRouteStopIcon(index + 1, role),
        zIndexOffset: stop.id === selectedDraftStopId ? 1100 : 900,
        keyboard: true,
        title: `Điểm nháp ${index + 1}: ${station.name}`,
      });
      const label = document.createElement('span');
      label.textContent = `Nháp #${index + 1} · ${station.name} · Chưa tính tuyến`;
      marker.bindTooltip(label, { direction: 'top' });
      marker.on('click', () => {
        setSelectedDraftStopId(stop.id);
        setDrawerOpen(true);
        setActivePanel('context');
        focusLocation([station.latitude, station.longitude]);
      });
      marker.addTo(layer);
    });
  }, [draftStops, stations, workspace, plannedRoute, selectedDraftStopId, showRoutes, focusLocation]);

  const focusDraftStop = (id: string) => {
    setSelectedDraftStopId(id);
    const stop = draftStops.find(item => item.id === id);
    const station = stations.find(item => item.id === stop?.stationId);
    if (station) focusLocation([station.latitude, station.longitude], 16);
  };
  const handleFit = () => {
    if (workspace === 'simulation' && fleetPoints.length) { fitSimulationFleet(); return; }
    if (plannedRouteBoundsRef.current && showRoutes) {
      fitBounds(plannedRouteBoundsRef.current);
      return;
    }
    const draftStations = draftStops.map(stop => stations.find(station => station.id === stop.stationId)).filter(station => station !== undefined);
    const points = workspace === 'routes' && draftStations.length ? draftStations : showStations ? stations : [];
    if (points.length) fitBounds(L.latLngBounds(points.map(station => [station.latitude, station.longitude])));
  };

  // Helper: Pick map center coordinates
  const handlePickMapCenter = () => {
    const map = mapInstanceRef.current;
    if (!map) return;
    const center = getVisibleCenter();
    if (!center) return;
    setStationForm((cur) => ({
      ...cur,
      latitude: center.lat.toFixed(6),
      longitude: center.lng.toFixed(6),
    }));
    setPickingLocation(false);
    setDrawerOpen(true); setActivePanel('context');
    setToast('Đã gán tọa độ tâm bản đồ vào biểu mẫu.');
    focusLocation(center);
  };

  return (
    <section ref={rootRef} className={`map-first${embedded ? ' map-first-embedded' : ''}`} aria-label="Không gian bản đồ vận hành" data-workspace={workspace} data-sheet-expanded={sheetExpanded} data-drawer-open={contextVisible} data-alerts-open={alertsOpen}>
      <div id="main-map" ref={mapContainerRef} className="map-canvas" aria-label="Bản đồ tương tác" tabIndex={-1} />
      <TrafficLayer mapRef={mapInstanceRef} mapReady={mapReady} visible={showTraffic}
        incidents={traffic.incidents} />
      {workspace==='simulation' && <Suspense fallback={null}><SimulationFleetLayer mapRef={mapInstanceRef} mapReady={mapReady} visible
        vehicles={simulationFleet.previews} onSelect={selectSimulationVehicle} />
        <SimulationRoutesLayer mapRef={mapInstanceRef} mapReady={mapReady} visible={showRoutes}
          routes={selectedSimulationRoutes} selectedTripId={selectedTripId} onSelect={selectSimulationVehicle} /></Suspense>}
      {(plannedRoute || hasSimulationRoute) && <Suspense fallback={null}>
        <RouteInspectionLayer mapRef={mapInstanceRef} mapReady={mapReady}
          route={workspace === 'simulation' ? selectedSimulationRoutes[0]?.route ?? null : plannedRoute}
          visible={showRoutes && !pickingLocation && (workspace !== 'simulation' || hasSimulationRoute)}
          trafficEnabled={showTraffic} />
      </Suspense>}
      <ModeBar mode={workspace} onChange={selectMode} connectionLabel={connectionLabel} embedded={embedded} alertCount={unreadAlertCount} alertsOpen={alertsOpen} onOpenAlerts={() => { alertOpenerRef.current = 'mode'; openPanel('alerts'); }} />
      <div className="live-follow glass-panel" data-map-edge="top" hidden={!selectedVehicle && !selectedWaitingVehicle && !selectedPlannedVehicle}>
        {!selectedVehicle && selectedWaitingVehicle && <div className="live-follow-actions">
          <span>{selectedWaitingVehicle.trip.vehiclePlateNumber} · Chờ mô phỏng</span>
          <button aria-label="Bỏ chọn xe" disabled={simulator.busy} onClick={clearVehicleSelection}>×</button>
        </div>}
        {!selectedVehicle && !selectedWaitingVehicle && selectedPlannedVehicle && <div className="live-follow-actions">
          <span>{selectedPlannedVehicle.vehiclePlateNumber} · Chưa khởi hành</span>
          <button aria-label="Bỏ chọn xe" disabled={simulator.busy} onClick={clearVehicleSelection}>×</button>
        </div>}
        {selectedVehicle && <>
        <div className="live-follow-actions">
          <span>{live.snapshot?.trips.find(trip => trip.id === selectedVehicle.tripId)?.vehiclePlateNumber ?? selectedVehicle.vehicleId} · {selectedVehicle.source === 'SIMULATOR' ? 'Giả lập' : 'GPS'}</span>
          <button aria-pressed={followingVehicle} onClick={() => { setFollowingVehicle(value => !value); if (!followingVehicle) focusLocation([selectedVehicle.latitude, selectedVehicle.longitude], 16); }}>{followingVehicle ? 'Bỏ theo xe' : 'Theo xe'}</button>
          <button aria-label="Bỏ chọn xe" disabled={simulator.busy} onClick={clearVehicleSelection}>×</button>
        </div>
        <TripTrafficSummary key={`${selectedVehicle.tripId}:${selectedVehicle.attemptNumber ?? 1}`} context="vehicle" tripId={selectedVehicle.tripId} position={selectedVehicle}
          run={selectedVehicle.source === 'SIMULATOR' ? live.snapshot?.simulations.find(run => run.tripId === selectedVehicle.tripId) ?? null : null}
          now={live.now} connection={live.connection} />
        </>}
      </div>

      <aside className="context-drawer glass-panel" data-map-edge="left" hidden={!contextVisible} aria-label="Bảng dữ liệu vận hành">
        <div className="floating-panel-heading">
          <span><List size={15} />{workspace === 'tracking' || workspace === 'simulation' ? 'ĐỘI XE' : 'THIẾT LẬP LỘ TRÌNH'}</span>
          <div>
            <button className="sheet-expand" onClick={() => setSheetExpanded(value => !value)} aria-label={sheetExpanded ? 'Thu chiều cao bảng' : 'Mở rộng bảng'}>{sheetExpanded ? <ChevronDown size={16} /> : <ChevronUp size={16} />}</button>
            <button onClick={() => { setDrawerOpen(false); setActivePanel(null); rootRef.current?.querySelector<HTMLButtonElement>('.panel-launchers button')?.focus(); }} aria-label="Thu bảng dữ liệu"><PanelLeftClose size={16} /></button>
          </div>
        </div>
        <div className="planning-tabs" hidden={workspace !== 'stations' && workspace !== 'routes'} aria-label="Dữ liệu lộ trình">
          <button aria-pressed={workspace === 'routes'} onClick={() => selectMode('routes')}>Tuyến đường</button>
          <button aria-pressed={workspace === 'stations'} onClick={() => selectMode('stations')}>Trạm dừng <span>{stations.length}</span></button>
        </div>
        <div className="context-content" hidden={workspace !== 'tracking' && workspace !== 'simulation'}>
          <FleetWorkspace liveSnapshot={live.snapshot} tripSelection={tripSelection} onTripCreated={handleTripCreated} onSimulateTrip={openSimulation} onFocusVehicle={focusVehicle} onToast={setToast} onFocusStop={focusLocation} onManageRoutes={() => selectMode('routes')} onManageStations={() => selectMode('stations')} />
        </div>
        <div className="context-content station-workspace" hidden={workspace !== 'stations'}>
          <div className="panel-list-slot" hidden={formMode !== 'closed' || selectedStation !== null}>
            <StationPanel stations={stations} selectedStationId={selectedStationId} loading={loadingStations} error={formMode === 'closed' ? stationError : null} selectionDisabled={formMode !== 'closed'} mode={formMode} onBeginCreate={handleBeginCreate} onSelect={handleSelectStation} onBeginEdit={handleBeginEdit} onDelete={setDeleteCandidate} />
          </div>
          <StationDrawer station={selectedStation} mode={formMode} form={stationForm} saving={savingStation} error={stationError} pickingLocation={pickingLocation}
            onClose={handleCloseStationDrawer} onBeginEdit={() => handleBeginEdit()} onPickLocation={() => { setPickingLocation(true); setActivePanel(null); }}
            onFieldChange={handleFieldChange} onSave={handleSaveStation} onRequestDeactivate={() => selectedStation && setDeleteCandidate(selectedStation)} />
        </div>
        <div className="context-content" hidden={workspace !== 'routes'}>
          <RouteWorkspace mapRef={mapInstanceRef} stations={stations} loadingStations={loadingStations} onPlannedRouteDisplay={setPlannedRoute} onShowToast={setToast}
            onDraftStopsChange={setDraftStops} selectedDraftStopId={selectedDraftStopId} onFocusDraftStop={focusDraftStop} onFocusStop={focusLocation}
            refreshToken={routeRefreshToken} />
        </div>
        {(workspace === 'stations' || workspace === 'routes') && <div className="context-footer"><span className="status-dot" />{workspace === 'stations' ? 'Danh sách trạm đã lưu' : 'Quản lý tuyến đường'}</div>}
      </aside>

      <div className="operations-dock" data-map-edge="right" hidden={alertsOpen || (compact && activePanel !== 'simulator')}>
        <div className="floating-panel glass-panel" hidden={compact && activePanel !== 'simulator'}>
          <div className="floating-panel-heading"><span><Play size={15} />MÔ PHỎNG XE</span><div>
            <button className="sheet-expand" onClick={() => setSheetExpanded(value => !value)} aria-label={sheetExpanded ? 'Thu chiều cao bảng' : 'Mở rộng bảng'}>{sheetExpanded ? <ChevronDown size={16} /> : <ChevronUp size={16} />}</button>
            <button aria-label={simulatorExpanded ? 'Thu bảng mô phỏng' : 'Mở bảng mô phỏng'} aria-expanded={simulatorExpanded}
              onClick={() => { if (compact) setActivePanel(null); else setSimulatorExpanded(value => !value); }}><ChevronDown size={16} /></button>
          </div></div>
          <div className="floating-panel-body" hidden={!simulatorExpanded}><SimulatorPanel key={`${simulator.tripId ?? 'none'}:${simulator.run?.attemptNumber ?? 1}`} simulator={simulator} snapshot={live.snapshot} now={live.now} connection={live.connection} connectionError={live.error} onReconnect={live.reconnect}
            fleet={workspace==='simulation' ? simulationFleet : undefined} onSelectVehicle={selectSimulationVehicle} onFitFleet={fitSimulationFleet}
            onManageFleet={()=>{selectMode('tracking');setDrawerOpen(true);setActivePanel('context');}}
            onShowRoute={() => {
            setWorkspace('simulation'); onWorkspaceChange?.('simulation');
            if (simulator.trip) {
              const preview=simulationFleet.previews.find(item=>item.trip.id===simulator.tripId);
              if (preview) focusLocation([preview.start.latitude,preview.start.longitude],16);
              else { focusVehicle(simulator.trip.vehicleId); setFollowingVehicle(true); }
            }
          }} /></div>
        </div>
      </div>

      <aside id="operations-alert-drawer" className="alert-drawer glass-panel" role="region" aria-label="Thông báo vận hành" hidden={!alertsOpen}>
        <div className="floating-panel-heading">
          <span><Bell size={15} />THÔNG BÁO VẬN HÀNH</span>
          <div>
            <span className="count-badge">{unreadAlertCount ?? '—'}</span>
            <button ref={alertCloseButtonRef} type="button" onClick={closeAlerts} aria-label="Đóng thông báo vận hành"><X size={16} /></button>
          </div>
        </div>
        <div className="floating-panel-body">
          {live.snapshot ? <AlertStream notifications={live.snapshot.notifications} onUnreadCountChange={reportUnreadAlertCount} /> : <div className="alert-drawer-status">
            <Bell size={22} />
            <strong>{live.error ? 'Chưa tải được thông báo' : 'Đang tải thông báo vận hành…'}</strong>
            <p>{live.error ?? 'Đang chờ dữ liệu vận hành đầu tiên từ máy chủ.'}</p>
            {live.error && <button type="button" className="alert-reconnect-button" onClick={live.reconnect}>Thử kết nối lại</button>}
          </div>}
        </div>
      </aside>

      <div className="panel-launchers" data-map-edge="bottom" aria-label="Mở bảng công cụ">
        <button onClick={() => openPanel('context')} aria-pressed={contextVisible}><List size={16} /><span>{workspace === 'tracking' || workspace === 'simulation' ? 'Đội xe' : 'Tuyến & trạm'}</span></button>
        <button onClick={() => openPanel('simulator')} aria-pressed={compact ? activePanel === 'simulator' : simulatorExpanded}><Play size={16} /><span>Mô phỏng</span></button>
        <button className="panel-alert-launcher" onClick={() => { alertOpenerRef.current = 'launcher'; openPanel('alerts'); }} aria-pressed={alertsOpen}><Bell size={16} /><span>Cảnh báo</span>{unreadAlertCount !== null && unreadAlertCount > 0 && <b>{unreadAlertCount > 99 ? '99+' : unreadAlertCount}</b>}</button>
      </div>

      <div className="map-picking-banner" role="status" hidden={!pickingLocation || workspace !== 'stations'}>
        <Crosshair size={17} /><span>Kéo bản đồ để đưa vị trí trạm vào tâm ngắm</span>
        <button className="picking-center-btn" onClick={handlePickMapCenter}>Chọn vị trí này</button>
        <button className="picking-cancel-btn" onClick={() => { setPickingLocation(false); openPanel('context'); }} aria-label="Hủy chế độ chọn vị trí"><X size={16} /></button>
      </div>
      <div className="station-center-target" hidden={!pickingLocation || workspace !== 'stations'} aria-hidden="true">
        <span />
      </div>

      <MapControls theme={theme} onThemeChange={setTheme}
        onResetCenter={() => focusLocation(HCMC_CENTER, 13)}
        onZoomIn={() => mapInstanceRef.current?.zoomIn()} onZoomOut={() => mapInstanceRef.current?.zoomOut()}
        onFit={handleFit} canFit={(workspace==='simulation' && fleetPoints.length>0) || (showStations && stations.length > 0) || (showRoutes && (plannedRoute !== null || draftStops.length > 0))}
        showStations={showStations} showRoutes={showRoutes} onToggleStations={() => setShowStations(value => !value)} onToggleRoutes={() => setShowRoutes(value => !value)}
        showTraffic={showTraffic} onToggleTraffic={() => setShowTraffic(value => !value)} trafficMessage={trafficMessage}
        trafficCanRetry={Boolean(traffic.error) || trafficStatus === 'UNAVAILABLE'} onRetryTraffic={traffic.refresh} />
      {deleteCandidate && <ConfirmStationDelete station={deleteCandidate} saving={deletingStation} onCancel={() => setDeleteCandidate(null)} onConfirm={handleDeactivate} />}
      {toast && <div className="application-toast" role="status">{toast}</div>}
    </section>
  );
};
