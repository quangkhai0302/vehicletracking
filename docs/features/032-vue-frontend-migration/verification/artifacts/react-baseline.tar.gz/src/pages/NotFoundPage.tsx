import { ArrowLeft, MapPinOff } from 'lucide-react';
import { Link } from 'react-router-dom';

export function NotFoundPage() {
  return <div className="business-page not-found-page"><section className="business-surface"><MapPinOff size={34} /><span>LỖI 404</span><h2>Trang bạn cần không tồn tại</h2><p>Đường dẫn có thể đã thay đổi hoặc chưa được cấu hình trong hệ thống.</p><Link to="/dashboard"><ArrowLeft size={16} />Quay lại dashboard</Link></section></div>;
}
