import { useEffect, useMemo, useState } from 'react';
import { AlertTriangle, ArrowRight, BellRing, BusFront, CalendarClock, CheckCircle2, CircleDashed, Clock3, MapPinned, UserRound } from 'lucide-react';
import { Link } from 'react-router-dom';
import { fetchTrips } from '../services/fleet';
import { fetchDashboardSummary } from '../services/dashboard';
import type { TripSummary } from '../types/fleet';
import { TRIP_STATUS_LABELS } from '../types/fleet';
import type { DashboardSummary } from '../types/dashboard';
import { displayTripTime } from '../utils/tripTime';
import './business-pages.css';
import { PageHeading } from '../components/business/PageHeading';

interface DashboardData {
  summary: DashboardSummary;
  trips: TripSummary[];
}

function isOverdue(trip: TripSummary, serverTime: string) {
  if (trip.status !== 'IN_PROGRESS') return false;
  return Date.parse(trip.plannedEndAt) < Date.parse(serverTime);
}

export function DashboardPage() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    let disposed = false;
    const controller = new AbortController();
    const load = (showLoading: boolean) => {
      if (showLoading) setLoading(true);
      Promise.all([fetchDashboardSummary(controller.signal), fetchTrips(controller.signal)])
        .then(([summary, trips]) => {
          if (!disposed) { setData({ summary, trips }); setError(null); }
        })
        .catch((reason: unknown) => {
          if (!disposed && reason instanceof DOMException && reason.name === 'AbortError') return;
          if (!disposed) setError(reason instanceof Error ? reason.message : 'Không thể tải dữ liệu tổng quan.');
        })
        .finally(() => { if (!disposed) setLoading(false); });
    };
    load(true);
    const timer = window.setInterval(() => load(false), 15_000);
    return () => { disposed = true; controller.abort(); window.clearInterval(timer); };
  }, [attempt]);

  const recentTrips = useMemo(() => [...(data?.trips ?? [])]
    .sort((left, right) => Date.parse(right.scheduledDepartureAt) - Date.parse(left.scheduledDepartureAt) || right.id - left.id)
    .slice(0, 6), [data]);

  const metricCards = [
    { label: 'Phương tiện hoạt động', value: data?.summary.activeVehicleCount, detail: 'Danh mục xe đang sử dụng', icon: BusFront, tone: 'blue' },
    { label: 'Tài xế hoạt động', value: data?.summary.activeDriverCount, detail: 'Sẵn sàng nhận phân công', icon: UserRound, tone: 'cyan' },
    { label: 'Chuyến đang chạy', value: data?.summary.tripsInProgress, detail: 'Đang thực hiện trên tuyến', icon: Clock3, tone: 'amber' },
    { label: 'Chuyến chờ khởi hành', value: data?.summary.scheduledTrips, detail: 'Đã lập lịch và chưa bắt đầu', icon: CalendarClock, tone: 'violet' },
    { label: 'Chuyến hoàn thành', value: data?.summary.completedTrips, detail: 'Tổng chuyến đã hoàn thành', icon: CheckCircle2, tone: 'green' },
    { label: 'Chuyến đang trễ', value: data?.summary.overdueTrips, detail: 'Đang chạy quá giờ dự kiến', icon: Clock3, tone: 'red' },
    { label: 'Xe lệch tuyến', value: data?.summary.offRouteVehicleCount, detail: 'Cảnh báo lệch tuyến đang mở', icon: MapPinned, tone: 'red' },
    { label: 'Cảnh báo cần xử lý', value: data?.summary.unreadAlertCount, detail: 'Thông báo chưa được đánh dấu', icon: BellRing, tone: 'amber' },
    { label: 'Chuyến đã hủy', value: data?.summary.cancelledTrips, detail: 'Tổng chuyến đã hủy', icon: AlertTriangle, tone: 'violet' },
  ];

  return <div className="business-page dashboard-page">
    <PageHeading eyebrow="TRUNG TÂM ĐIỀU HÀNH" title="Tổng quan vận hành" description="Nắm bắt tình hình đội xe, chuyến đi và những việc cần xử lý."
      actions={<Link className="business-button primary" to="/operations"><MapPinned size={17} />Mở bản đồ giám sát <ArrowRight size={15} /></Link>} />
    <div className="dashboard-section-label"><h3>Hoạt động đội xe</h3><span>Cập nhật mỗi 15 giây</span></div>

    {error && <div className="dashboard-error" role="alert"><AlertTriangle size={19} /><div><strong>Chưa tải được dữ liệu dashboard</strong><p>{error}</p></div><button onClick={() => { setLoading(true); setError(null); setAttempt(value => value + 1); }}>Thử lại</button></div>}

    <section className="dashboard-metrics" aria-busy={loading} aria-label="Chỉ số vận hành">
      {metricCards.map(card => {
        const Icon = card.icon;
        return <article key={card.label} className={`dashboard-metric ${card.tone}`}>
          <span className="dashboard-metric-icon"><Icon size={20} /></span>
          <div><span>{card.label}</span><strong>{loading || card.value === undefined ? <span className="dashboard-loading-value" /> : card.value}</strong><small>{card.detail}</small></div>
        </article>;
      })}
    </section>

    <div className="dashboard-columns">
      <section className="business-surface dashboard-trips">
        <div className="dashboard-card-heading"><div><h2>Chuyến đi gần đây</h2><p>Danh sách theo thời gian khởi hành đã lập.</p></div><Link to="/trips">Xem tất cả <ArrowRight size={14} /></Link></div>
        {loading && <p className="dashboard-state" role="status">Đang tải chuyến đi…</p>}
        {!loading && !error && recentTrips.length === 0 && <div className="dashboard-empty"><CalendarClock size={28} /><strong>Chưa có chuyến đi</strong><p>Tạo chuyến đầu tiên từ module Chuyến đi.</p><Link to="/trips">Tạo chuyến</Link></div>}
        {!loading && recentTrips.length > 0 && <div className="dashboard-trip-list">{recentTrips.map(trip => <Link key={trip.id} to="/trips" className="dashboard-trip-row">
          <span className="dashboard-trip-id">#{trip.id}</span><span><strong>{trip.routeName}</strong><small>{trip.vehiclePlateNumber} · {trip.driver?.fullName ?? 'Chưa gán tài xế'}</small></span>
          <time>{displayTripTime(trip.scheduledDepartureAt)}</time><span className={`dashboard-status ${trip.status.toLowerCase()}`}>{isOverdue(trip, data?.summary.serverTime ?? new Date().toISOString()) ? 'Đang trễ' : TRIP_STATUS_LABELS[trip.status]}</span>
        </Link>)}</div>}
      </section>

      <aside className="dashboard-side-column">
        <section className="business-surface dashboard-quick-links"><div className="dashboard-card-heading"><div><h2>Thao tác nhanh</h2><p>Đi đến nghiệp vụ thường dùng.</p></div></div>
          <Link to="/vehicles"><BusFront size={18} /><span><strong>Quản lý phương tiện</strong><small>Hồ sơ xe và phân công tài xế</small></span><ArrowRight size={15} /></Link>
          <Link to="/drivers"><UserRound size={18} /><span><strong>Quản lý tài xế</strong><small>Thông tin và trạng thái hoạt động</small></span><ArrowRight size={15} /></Link>
          <Link to="/trips"><CalendarClock size={18} /><span><strong>Lập chuyến đi</strong><small>Chọn xe, tuyến và tài xế</small></span><ArrowRight size={15} /></Link>
        </section>
        <section className="business-surface dashboard-alerts"><div className="dashboard-card-heading"><div><h2>Cảnh báo cần xử lý</h2><p>{data ? `${data.summary.unreadAlertCount} cảnh báo chưa đọc` : 'Đang tải dữ liệu cảnh báo'}</p></div><Link to="/alerts">Mở trung tâm <ArrowRight size={14} /></Link></div>
          {loading && <p className="dashboard-state" role="status">Đang tải cảnh báo…</p>}
          {!loading && !error && data?.summary.pendingAlerts.length === 0 && <div className="dashboard-empty"><CircleDashed size={28} /><strong>Không có cảnh báo mới</strong><p>Hệ thống sẽ hiển thị cảnh báo khi có sự cố cần xử lý.</p></div>}
          {!loading && data?.summary.pendingAlerts.map(alert => <Link key={alert.id} to={`/operations?tripId=${alert.tripId}`} className="dashboard-alert-row">
            <span className={`dashboard-alert-icon ${alert.type === 'OFF_ROUTE_DETECTED' ? 'off-route' : 'reroute'}`}>{alert.type === 'OFF_ROUTE_DETECTED' ? <MapPinned size={15} /> : <AlertTriangle size={15} />}</span>
            <span><strong>{alert.title}</strong><small>{alert.vehiclePlateNumber} · Chuyến #{alert.tripId}</small></span><ArrowRight size={14} />
          </Link>)}
        </section>
      </aside>
    </div>
  </div>;
}
