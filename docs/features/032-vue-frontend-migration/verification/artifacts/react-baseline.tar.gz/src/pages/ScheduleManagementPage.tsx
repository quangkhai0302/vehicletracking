import { useEffect, useMemo, useRef, useState } from 'react';
import { CalendarClock, CheckCircle2, ChevronRight, Pencil, Plus, Power, RotateCcw, TriangleAlert, X } from 'lucide-react';
import { Link } from 'react-router-dom';
import { fetchDrivers, fetchFleetVehicles } from '../services/fleet';
import { createSchedule, fetchSchedules, setScheduleEnabled, updateSchedule } from '../services/schedules';
import { fetchRoutes } from '../services/routes';
import type { Driver, FleetVehicle } from '../types/fleet';
import type { RouteSummary } from '../types/route';
import type { ScheduleFrequency, TripSchedule, TripScheduleInput } from '../types/schedule';
import './schedule-management.css';
import { PageHeading } from '../components/business/PageHeading';
import { SidePanel } from '../components/business/SidePanel';

interface ScheduleData { schedules: TripSchedule[]; routes: RouteSummary[]; vehicles: FleetVehicle[]; drivers: Driver[] }
interface FormState extends TripScheduleInput { id: number | null }

const weekdays = [
  { bit: 1, label: 'T2' }, { bit: 2, label: 'T3' }, { bit: 4, label: 'T4' }, { bit: 8, label: 'T5' },
  { bit: 16, label: 'T6' }, { bit: 32, label: 'T7' }, { bit: 64, label: 'CN' },
];

const today = () => new Date().toLocaleDateString('en-CA');
const defaultTimezone = 'Asia/Ho_Chi_Minh';
const blankForm = (): FormState => ({ id: null, name: '', routeId: 0, vehicleId: 0, driverId: 0, frequency: 'WEEKLY', scheduledDate: null, weekdaysMask: 31, departureTime: '08:00', timezone: defaultTimezone, effectiveFrom: today(), effectiveUntil: null });
const dateTime = (value: string | null, timezone: string) => value ? new Intl.DateTimeFormat('vi-VN', { dateStyle: 'short', timeStyle: 'short', timeZone: timezone }).format(new Date(value)) : 'Chưa có';
const dayLabels = (mask: number) => weekdays.filter(day => (mask & day.bit) !== 0).map(day => day.label).join(', ');

function scheduleToForm(schedule: TripSchedule): FormState {
  return { id: schedule.id, name: schedule.name ?? '', routeId: schedule.routeId, vehicleId: schedule.vehicleId, driverId: schedule.driverId, frequency: schedule.frequency, scheduledDate: schedule.scheduledDate, weekdaysMask: schedule.weekdaysMask, departureTime: schedule.departureTime.slice(0, 5), timezone: schedule.timezone, effectiveFrom: schedule.effectiveFrom, effectiveUntil: schedule.effectiveUntil };
}

function toInput(form: FormState): TripScheduleInput {
  return { name: form.name?.trim() || null, routeId: form.routeId, vehicleId: form.vehicleId, driverId: form.driverId, frequency: form.frequency, scheduledDate: form.frequency === 'ONCE' ? form.scheduledDate : null, weekdaysMask: form.frequency === 'WEEKLY' ? form.weekdaysMask : 0, departureTime: form.departureTime, timezone: form.timezone.trim(), effectiveFrom: form.effectiveFrom, effectiveUntil: form.effectiveUntil || null };
}

function ScheduleConfirm({ schedule, busy, error, onClose, onConfirm }: { schedule: TripSchedule; busy: boolean; error: string | null; onClose: () => void; onConfirm: () => void }) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => { const dialog = ref.current; dialog?.showModal(); return () => dialog?.close(); }, []);
  const action = schedule.enabled ? 'Tạm dừng' : 'Bật lại';
  return <dialog ref={ref} className="schedule-confirm" aria-labelledby="schedule-confirm-title" onCancel={event => { event.preventDefault(); if (!busy) onClose(); }}>
    <h2 id="schedule-confirm-title">{action} lịch chạy?</h2>
    <p>{schedule.enabled ? 'Hệ thống sẽ không tạo thêm chuyến mới từ lịch này. Những chuyến đã tạo vẫn được giữ nguyên.' : 'Hệ thống sẽ xét tạo chuyến mới theo cấu hình lịch này.'}</p>
    {error && <p className="schedule-inline-error" role="alert">{error}</p>}
    <div><button type="button" className="schedule-button-secondary" disabled={busy} autoFocus onClick={onClose}>Quay lại</button><button type="button" className={schedule.enabled ? 'schedule-button-danger' : 'schedule-button-primary'} disabled={busy} onClick={onConfirm}>{busy ? 'Đang xử lý…' : action}</button></div>
  </dialog>;
}

export function ScheduleManagementPage() {
  const [data, setData] = useState<ScheduleData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [attempt, setAttempt] = useState(0);
  const [routeFilter, setRouteFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'ENABLED' | 'DISABLED'>('ALL');
  const [editorOpen, setEditorOpen] = useState(false);
  const [form, setForm] = useState<FormState>(blankForm);
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [pendingToggle, setPendingToggle] = useState<TripSchedule | null>(null);
  const [toggleError, setToggleError] = useState<string | null>(null);
  const [toggling, setToggling] = useState(false);

  useEffect(() => {
    const controller = new AbortController();
    Promise.all([fetchSchedules(controller.signal), fetchRoutes(controller.signal), fetchFleetVehicles(controller.signal), fetchDrivers(controller.signal)])
      .then(([schedules, routes, vehicles, drivers]) => { if (!controller.signal.aborted) setData({ schedules, routes, vehicles, drivers }); })
      .catch((reason: unknown) => { if (!controller.signal.aborted) setError(reason instanceof Error ? reason.message : 'Không thể tải lịch chạy tự động.'); })
      .finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
  }, [attempt]);

  const schedules = useMemo(() => (data?.schedules ?? []).filter(schedule =>
    (!routeFilter || String(schedule.routeId) === routeFilter) &&
    (statusFilter === 'ALL' || (statusFilter === 'ENABLED' ? schedule.enabled : !schedule.enabled))), [data, routeFilter, statusFilter]);
  const metrics = useMemo(() => ({ total: data?.schedules.length ?? 0, active: data?.schedules.filter(schedule => schedule.enabled).length ?? 0, weekly: data?.schedules.filter(schedule => schedule.enabled && schedule.frequency === 'WEEKLY').length ?? 0 }), [data]);
  const activeRoutes = data?.routes.filter(route => route.active !== false) ?? [];
  const activeVehicles = data?.vehicles.filter(vehicle => vehicle.active) ?? [];
  const activeDrivers = data?.drivers.filter(driver => driver.active) ?? [];

  const openCreate = () => { setForm(blankForm()); setFormError(null); setEditorOpen(true); };
  const openEdit = (schedule: TripSchedule) => { setForm(scheduleToForm(schedule)); setFormError(null); setEditorOpen(true); };
  const updateForm = <K extends keyof FormState>(key: K, value: FormState[K]) => setForm(current => ({ ...current, [key]: value }));
  const save = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!form.routeId || !form.vehicleId || !form.driverId || !form.departureTime || !form.timezone || !form.effectiveFrom) { setFormError('Hãy chọn tuyến, xe, tài xế và điền đầy đủ thời gian hiệu lực.'); return; }
    if (form.frequency === 'ONCE' && !form.scheduledDate) { setFormError('Lịch một lần cần ngày chạy cụ thể.'); return; }
    if (form.frequency === 'WEEKLY' && form.weekdaysMask === 0) { setFormError('Hãy chọn ít nhất một ngày trong tuần.'); return; }
    if (form.effectiveUntil && form.effectiveUntil < form.effectiveFrom) { setFormError('Ngày kết thúc phải sau hoặc bằng ngày bắt đầu.'); return; }
    setSaving(true); setFormError(null);
    try {
      const saved = form.id ? await updateSchedule(form.id, toInput(form)) : await createSchedule(toInput(form));
      setData(current => current ? { ...current, schedules: form.id ? current.schedules.map(item => item.id === saved.id ? saved : item) : [saved, ...current.schedules] } : current);
      setEditorOpen(false);
    } catch (reason) { setFormError(reason instanceof Error ? reason.message : 'Không thể lưu lịch chạy.'); }
    finally { setSaving(false); }
  };
  const toggle = async () => {
    if (!pendingToggle) return;
    setToggling(true); setToggleError(null);
    try {
      const saved = await setScheduleEnabled(pendingToggle.id, !pendingToggle.enabled);
      setData(current => current ? { ...current, schedules: current.schedules.map(item => item.id === saved.id ? saved : item) } : current);
      setPendingToggle(null);
    } catch (reason) { setToggleError(reason instanceof Error ? reason.message : 'Không thể thay đổi trạng thái lịch.'); }
    finally { setToggling(false); }
  };

  return <div className="business-page schedule-page">
    <PageHeading eyebrow="ĐIỀU PHỐI HÀNH TRÌNH" title="Lịch chạy tự động" description="Thiết lập lịch cố định, phân công phương tiện và tài xế cho từng tuyến."
      actions={<button className="business-button primary" onClick={openCreate}><Plus size={17} />Tạo lịch chạy</button>} />
    <section className="schedule-metrics" aria-label="Chỉ số lịch chạy" aria-busy={loading}>
      <article><CalendarClock size={20} /><div><span>Tổng lịch chạy</span><strong>{loading ? '—' : metrics.total}</strong></div></article>
      <article><CheckCircle2 size={20} /><div><span>Đang hoạt động</span><strong>{loading ? '—' : metrics.active}</strong></div></article>
      <article><RotateCcw size={20} /><div><span>Lặp hàng tuần</span><strong>{loading ? '—' : metrics.weekly}</strong></div></article>
    </section>
    {error && <section className="schedule-error" role="alert"><TriangleAlert size={19} /><div><strong>Không thể tải lịch chạy</strong><p>{error}</p></div><button onClick={() => { setLoading(true); setError(null); setAttempt(value => value + 1); }}>Thử lại</button></section>}
    <section className="business-surface schedule-list-panel">
      <div className="schedule-list-heading"><div><h2>Danh sách lịch chạy</h2><p>Thay đổi cấu hình chỉ áp dụng cho các chuyến sẽ được tạo sau đó.</p></div><span>{loading ? 'Đang tải…' : `${schedules.length} lịch`}</span></div>
      <div className="schedule-filters"><label>Tuyến<select value={routeFilter} onChange={event => setRouteFilter(event.target.value)}><option value="">Tất cả tuyến</option>{data?.routes.map(route => <option key={route.id} value={route.id}>{route.name}</option>)}</select></label><label>Trạng thái<select value={statusFilter} onChange={event => setStatusFilter(event.target.value as typeof statusFilter)}><option value="ALL">Tất cả trạng thái</option><option value="ENABLED">Đang hoạt động</option><option value="DISABLED">Đã tạm dừng</option></select></label>{(routeFilter || statusFilter !== 'ALL') && <button className="schedule-clear-filter" onClick={() => { setRouteFilter(''); setStatusFilter('ALL'); }}>Xóa bộ lọc</button>}</div>
      {loading && <p className="schedule-state" role="status">Đang tải cấu hình lịch chạy…</p>}
      {!loading && !error && schedules.length === 0 && <div className="schedule-empty"><CalendarClock size={30} /><strong>{data?.schedules.length ? 'Không có lịch phù hợp' : 'Chưa có lịch chạy tự động'}</strong><p>{data?.schedules.length ? 'Thử thay đổi bộ lọc để xem lịch khác.' : 'Tạo lịch đầu tiên để hệ thống tự động lập chuyến theo tuyến.'}</p>{!data?.schedules.length && <button className="schedule-button-primary" onClick={openCreate}><Plus size={15} />Tạo lịch chạy</button>}</div>}
      {!loading && schedules.length > 0 && <div className="schedule-cards">{schedules.map(schedule => <article key={schedule.id} className="schedule-card" data-enabled={schedule.enabled}>
        <div className="schedule-card-header"><span className={schedule.enabled ? 'schedule-status active' : 'schedule-status paused'}>{schedule.enabled ? 'Đang hoạt động' : 'Tạm dừng'}</span><div><button aria-label={`Sửa lịch ${schedule.name || schedule.routeName}`} onClick={() => openEdit(schedule)}><Pencil size={15} /></button><button aria-label={`${schedule.enabled ? 'Tạm dừng' : 'Bật'} lịch ${schedule.name || schedule.routeName}`} onClick={() => { setToggleError(null); setPendingToggle(schedule); }}><Power size={15} /></button></div></div>
        <h3>{schedule.name || schedule.routeName}</h3><p className="schedule-route">{schedule.routeName}</p>
        <dl><div><dt>Tần suất</dt><dd>{schedule.frequency === 'ONCE' ? `Một lần · ${schedule.scheduledDate ?? '—'}` : `Hàng tuần · ${dayLabels(schedule.weekdaysMask)}`}</dd></div><div><dt>Khởi hành</dt><dd>{schedule.departureTime.slice(0, 5)} · {schedule.timezone}</dd></div><div><dt>Phân công</dt><dd>{schedule.vehiclePlate} · {schedule.driverName}</dd></div><div><dt>Lần chạy kế tiếp</dt><dd>{dateTime(schedule.nextRunAt, schedule.timezone)}</dd></div></dl>
        {schedule.lastRunStatus && <p className={`schedule-last-run ${schedule.lastRunStatus === 'SUCCESS' ? 'success' : 'failed'}`}>{schedule.lastRunStatus === 'SUCCESS' ? 'Đã tạo chuyến theo lịch gần nhất' : 'Lần chạy gần nhất cần chú ý'}{schedule.lastRunMessage ? ` · ${schedule.lastRunMessage}` : ''}</p>}
        <Link to="/trips">Xem chuyến đi <ChevronRight size={14} /></Link>
      </article>)}</div>}
    </section>
    {editorOpen && <SidePanel className="schedule-editor" label={form.id ? "Chỉnh sửa lịch chạy" : "Tạo lịch chạy tự động"} busy={saving} onClose={() => setEditorOpen(false)}><header><div><span>{form.id ? 'CẬP NHẬT LỊCH' : 'LỊCH CHẠY MỚI'}</span><h2 id="schedule-editor-title">{form.id ? 'Chỉnh sửa lịch chạy' : 'Tạo lịch chạy tự động'}</h2></div><button aria-label="Đóng biểu mẫu" disabled={saving} onClick={() => setEditorOpen(false)}><X size={18} /></button></header><form onSubmit={save}>
      {formError && <p className="schedule-inline-error" role="alert">{formError}</p>}
      <label>Tên lịch <input value={form.name ?? ''} maxLength={150} placeholder="Ví dụ: Tuyến sáng ngày thường" onChange={event => updateForm('name', event.target.value)} /></label>
      <div className="schedule-form-grid"><label>Tuyến đường<select required value={form.routeId || ''} onChange={event => updateForm('routeId', Number(event.target.value))}><option value="">Chọn tuyến</option>{activeRoutes.map(route => <option key={route.id} value={route.id}>{route.name}</option>)}</select></label><label>Phương tiện<select required value={form.vehicleId || ''} onChange={event => updateForm('vehicleId', Number(event.target.value))}><option value="">Chọn xe</option>{activeVehicles.map(vehicle => <option key={vehicle.id} value={vehicle.id}>{vehicle.plateNumber} · {vehicle.name}</option>)}</select></label><label>Tài xế<select required value={form.driverId || ''} onChange={event => updateForm('driverId', Number(event.target.value))}><option value="">Chọn tài xế</option>{activeDrivers.map(driver => <option key={driver.id} value={driver.id}>{driver.fullName} · {driver.licenseNumber}</option>)}</select></label><label>Múi giờ<input required value={form.timezone} placeholder="Asia/Ho_Chi_Minh" onChange={event => updateForm('timezone', event.target.value)} /></label></div>
      <fieldset><legend>Tần suất</legend><div className="schedule-frequency"><label><input type="radio" checked={form.frequency === 'ONCE'} onChange={() => updateForm('frequency', 'ONCE' as ScheduleFrequency)} />Một lần</label><label><input type="radio" checked={form.frequency === 'WEEKLY'} onChange={() => updateForm('frequency', 'WEEKLY' as ScheduleFrequency)} />Hàng tuần</label></div>{form.frequency === 'ONCE' ? <label>Ngày chạy<input required type="date" value={form.scheduledDate ?? ''} onChange={event => updateForm('scheduledDate', event.target.value || null)} /></label> : <div className="schedule-weekdays" aria-label="Ngày chạy trong tuần">{weekdays.map(day => <label key={day.bit}><input type="checkbox" checked={(form.weekdaysMask & day.bit) !== 0} onChange={() => updateForm('weekdaysMask', form.weekdaysMask ^ day.bit)} /><span>{day.label}</span></label>)}</div>}</fieldset>
      <div className="schedule-form-grid"><label>Giờ khởi hành<input required type="time" value={form.departureTime} onChange={event => updateForm('departureTime', event.target.value)} /></label><label>Hiệu lực từ<input required type="date" value={form.effectiveFrom} onChange={event => updateForm('effectiveFrom', event.target.value)} /></label><label>Hiệu lực đến <small>(không bắt buộc)</small><input type="date" value={form.effectiveUntil ?? ''} min={form.effectiveFrom} onChange={event => updateForm('effectiveUntil', event.target.value || null)} /></label></div>
      <footer><button type="button" className="schedule-button-secondary" disabled={saving} onClick={() => setEditorOpen(false)}>Hủy</button><button className="schedule-button-primary" disabled={saving}>{saving ? 'Đang lưu…' : form.id ? 'Lưu thay đổi' : 'Tạo lịch chạy'}</button></footer>
    </form></SidePanel>}
    {pendingToggle && <ScheduleConfirm schedule={pendingToggle} busy={toggling} error={toggleError} onClose={() => setPendingToggle(null)} onConfirm={() => void toggle()} />}
  </div>;
}
