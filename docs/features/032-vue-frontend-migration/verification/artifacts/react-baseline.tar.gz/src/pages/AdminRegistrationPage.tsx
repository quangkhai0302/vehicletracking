import { FormEvent, useState } from 'react';
import { ArrowLeft, ArrowRight, LockKeyhole, Navigation, TriangleAlert, UserRound } from 'lucide-react';
import { Link, Navigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { registerAdmin } from '../services/auth';
import './auth-pages.css';
import { AuthLayout } from '../components/business/AuthLayout';

export function AdminRegistrationPage() {
  const { user, loading } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  if (!loading && user) return <Navigate to={user.role === 'DRIVER' ? '/driver/today' : '/dashboard'} replace />;

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setError(null);
    if (password !== confirmPassword) {
      setError('Mật khẩu xác nhận không khớp.');
      return;
    }
    setBusy(true);
    try {
      await registerAdmin({ username: username.trim(), password });
      setSuccess(true);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Không thể tạo tài khoản admin.');
    } finally {
      setBusy(false);
    }
  };

  return <AuthLayout>
    <div className="auth-brand"><span><Navigation size={20} /></span><div><strong>Vehicle Tracking</strong><small>Operations Manager</small></div></div>
    <div className="auth-heading"><span>ĐĂNG KÝ TÀI KHOẢN</span><h1>Tạo tài khoản quản trị</h1><p>Tạo tài khoản admin để bắt đầu quản lý vận hành.</p></div>
    {error && <div className="auth-error" role="alert"><TriangleAlert size={17} /><span>{error}</span></div>}
    {success ? <div className="auth-success" role="status">
      <strong>Đăng ký thành công</strong>
      <span>Tài khoản <b>{username.trim().toLowerCase()}</b> đã được tạo. Bạn có thể đăng nhập ngay.</span>
      <Link to="/login">Đi tới đăng nhập <ArrowRight size={15} /></Link>
    </div> : <form onSubmit={submit} className="auth-form">
      <label><span>Tên đăng nhập</span><div className="auth-input"><UserRound size={16} /><input required minLength={3} maxLength={100} autoComplete="username" value={username} onChange={event => setUsername(event.target.value)} /></div></label>
      <label><span>Mật khẩu (tối thiểu 12 ký tự)</span><div className="auth-input"><LockKeyhole size={16} /><input required minLength={12} maxLength={100} type="password" autoComplete="new-password" value={password} onChange={event => setPassword(event.target.value)} /></div></label>
      <label><span>Xác nhận mật khẩu</span><div className="auth-input"><LockKeyhole size={16} /><input required minLength={12} maxLength={100} type="password" autoComplete="new-password" value={confirmPassword} onChange={event => setConfirmPassword(event.target.value)} /></div></label>
      <button type="submit" disabled={busy}>{busy ? 'Đang tạo tài khoản…' : 'Tạo tài khoản admin'}<ArrowRight size={16} /></button>
    </form>}
    <p className="auth-note">Tài khoản mới được tạo với quyền quản trị hệ thống.</p>
    <Link className="auth-link auth-back-link" to="/login"><ArrowLeft size={14} />Quay lại đăng nhập</Link>
  </AuthLayout>;
}
