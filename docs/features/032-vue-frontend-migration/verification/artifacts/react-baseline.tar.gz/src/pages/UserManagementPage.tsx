import { useEffect, useState } from 'react';
import { KeyRound, Plus, ShieldCheck, TriangleAlert, UserRound } from 'lucide-react';
import { createDriverAccount, fetchUserAccounts, setUserAccountActive, type UserAccount } from '../services/users';
import { fetchDrivers } from '../services/fleet';
import type { Driver } from '../types/fleet';
import './user-management.css';
import { PageHeading } from '../components/business/PageHeading';

export function UserManagementPage() {
  const [accounts, setAccounts] = useState<UserAccount[]>([]);
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [form, setForm] = useState({ username: '', password: '', driverId: '' });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const load = () => {
    const controller = new AbortController(); setLoading(true); setError(null);
    Promise.all([fetchUserAccounts(controller.signal), fetchDrivers(controller.signal)])
      .then(([nextAccounts, nextDrivers]) => { if (!controller.signal.aborted) { setAccounts(nextAccounts); setDrivers(nextDrivers); } })
      .catch(reason => { if (!controller.signal.aborted) setError(reason instanceof Error ? reason.message : 'Không thể tải tài khoản.'); })
      .finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return controller;
  };
  useEffect(() => { const controller = load(); return () => controller.abort(); }, []);

  const availableDrivers = drivers.filter(driver => driver.active && !accounts.some(account => account.driverId === driver.id));
  const submit = async (event: React.FormEvent) => {
    event.preventDefault(); setSaving(true); setError(null); setNotice(null);
    try {
      const created = await createDriverAccount({ username: form.username.trim(), password: form.password, driverId: Number(form.driverId) });
      setAccounts(current => [...current, created].sort((a, b) => a.username.localeCompare(b.username)));
      setForm({ username: '', password: '', driverId: '' }); setNotice('Đã tạo tài khoản tài xế.');
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Không thể tạo tài khoản.'); }
    finally { setSaving(false); }
  };
  const toggle = async (account: UserAccount) => {
    try { const updated = await setUserAccountActive(account.id, !account.active); setAccounts(current => current.map(item => item.id === updated.id ? updated : item)); }
    catch (reason) { setError(reason instanceof Error ? reason.message : 'Không thể thay đổi trạng thái tài khoản.'); }
  };

  return <div className="business-page users-page"><PageHeading eyebrow="QUẢN TRỊ HỆ THỐNG" title="Người dùng và phân quyền" description="Quản lý tài khoản và cấp quyền truy cập cho đội ngũ tài xế." />
    {error && <div className="users-error" role="alert"><TriangleAlert size={18} /><span>{error}</span><button onClick={() => { void load(); }}>Thử lại</button></div>}{notice && <div className="users-notice" role="status">{notice}</div>}
    <div className="users-columns"><section className="business-surface users-list"><div className="users-heading"><div><h2>Tài khoản hệ thống</h2><p>Danh sách tài khoản và quyền truy cập hiện tại.</p></div><span>{loading ? 'Đang tải…' : `${accounts.length} tài khoản`}</span></div>{loading && <p className="users-state">Đang tải tài khoản…</p>}{!loading && accounts.length === 0 && <div className="users-empty"><UserRound size={28} /><strong>Chưa có tài khoản</strong><p>Các tài khoản được tạo sẽ hiển thị tại đây.</p></div>}{!loading && accounts.map(account => <article className="user-row" key={account.id}><span className={`user-role ${account.role.toLowerCase()}`}><ShieldCheck size={14} />{account.role === 'ADMIN' ? 'Admin' : 'Tài xế'}</span><div><strong>{account.username}</strong><small>{account.driverName ? `${account.driverName} · GPLX ${account.driverLicenseNumber}` : 'Quản trị toàn hệ thống'}</small></div><span className={account.active ? 'user-active' : 'user-inactive'}>{account.active ? 'Đang hoạt động' : 'Đã khóa'}</span>{account.role === 'DRIVER' && <button onClick={() => void toggle(account)}>{account.active ? 'Khóa' : 'Mở khóa'}</button>}</article>)}</section>
      <section className="business-surface user-create"><div className="users-heading"><div><h2>Cấp tài khoản tài xế</h2><p>Một tài xế chỉ có tối đa một tài khoản.</p></div><KeyRound size={19} /></div><form onSubmit={submit}><label>Tên đăng nhập<input required pattern="[a-z0-9][a-z0-9._-]{2,99}" value={form.username} onChange={event => setForm(current => ({ ...current, username: event.target.value }))} placeholder="nguyen.van.a" /></label><label>Mật khẩu tạm thời<input required minLength={8} type="password" value={form.password} onChange={event => setForm(current => ({ ...current, password: event.target.value }))} placeholder="Tối thiểu 8 ký tự" /></label><label>Hồ sơ tài xế<select required value={form.driverId} onChange={event => setForm(current => ({ ...current, driverId: event.target.value }))}><option value="">Chọn tài xế</option>{availableDrivers.map(driver => <option key={driver.id} value={driver.id}>{driver.fullName} · {driver.licenseNumber}</option>)}</select></label><button disabled={saving || availableDrivers.length === 0}><Plus size={15} />{saving ? 'Đang tạo…' : 'Tạo tài khoản'}</button>{availableDrivers.length === 0 && <p className="user-create-help">Tất cả tài xế đang hoạt động đã được cấp tài khoản.</p>}</form></section></div>
  </div>;
}
