import { FormEvent, useState } from 'react';
import { ArrowRight, LockKeyhole, Navigation, TriangleAlert, UserRound } from 'lucide-react';
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import './auth-pages.css';
import { AuthLayout } from '../components/business/AuthLayout';

export function LoginPage() {
  const { user, login, loading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  if (!loading && user) return <Navigate to={user.role === 'DRIVER' ? '/driver/today' : '/dashboard'} replace />;

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setBusy(true); setError(null);
    try {
      const next = await login({ username: username.trim(), password });
      const requested = (location.state as { from?: string } | null)?.from;
      navigate(requested && next.role === 'ADMIN' ? requested : next.role === 'DRIVER' ? '/driver/today' : '/dashboard', { replace: true });
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Không thể đăng nhập.');
    } finally { setBusy(false); }
  };

  return <AuthLayout>
    <div className="auth-brand"><span><Navigation size={20} /></span><div><strong>Vehicle Tracking</strong><small>Operations Manager</small></div></div>
    <div className="auth-heading"><span>ĐĂNG NHẬP HỆ THỐNG</span><h1>Chào mừng trở lại</h1><p>Đăng nhập để xem đúng không gian được phân quyền.</p></div>
    {error && <div className="auth-error" role="alert"><TriangleAlert size={17} /><span>{error}</span></div>}
    <form onSubmit={submit} className="auth-form">
      <label><span>Tên đăng nhập</span><div className="auth-input"><UserRound size={16} /><input required autoComplete="username" value={username} onChange={event => setUsername(event.target.value)} /></div></label>
      <label><span>Mật khẩu</span><div className="auth-input"><LockKeyhole size={16} /><input required type="password" autoComplete="current-password" value={password} onChange={event => setPassword(event.target.value)} /></div></label>
      <button type="submit" disabled={busy}>{busy ? 'Đang xác thực…' : 'Đăng nhập'}<ArrowRight size={16} /></button>
    </form>
    <p className="auth-note">Tài khoản tài xế chỉ xem các chuyến và lịch được phân công.</p>
    <Link className="auth-link" to="/register">Đăng ký tài khoản quản trị</Link>
  </AuthLayout>;
}
