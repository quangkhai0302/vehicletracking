import { useEffect, useMemo, useState } from 'react';
import { AlertTriangle, BellRing, Check, CheckCheck, MapPinned, RefreshCw, Route, Trash2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { FleetConfirmDialog } from '../components/fleet/FleetConfirmDialog';
import { deleteNotification, fetchNotifications, markAllNotificationsRead, markNotificationRead } from '../services/notifications';
import type { NotificationItem, NotificationType } from '../types/notifications';
import './alerts-management.css';
import { PageHeading } from '../components/business/PageHeading';

type TypeFilter = 'ALL' | 'OFF_ROUTE_DETECTED' | 'REROUTE';
type SeverityFilter = 'ALL' | 'CRITICAL' | 'MAJOR';

const formatDistance = (meters?: number | null) => meters == null ? null : `${Math.round(meters)} m`;
const formatDateTime = (value: string) => new Intl.DateTimeFormat('vi-VN', { dateStyle: 'short', timeStyle: 'medium' }).format(new Date(value));
const isReroute = (type: NotificationType) => type === 'REROUTE_CREATED' || type === 'REROUTE_UNAVAILABLE';

function alertDetail(item: NotificationItem) {
  if (item.type !== 'OFF_ROUTE_DETECTED') return item.reason;
  const distance = formatDistance(item.measuredDistanceMeters);
  const threshold = formatDistance(item.thresholdDistanceMeters);
  const duration = item.breachDurationSeconds == null ? null : `${item.breachDurationSeconds}s`;
  return [distance && `Khoảng cách ${distance}`, threshold && `ngưỡng ${threshold}`, duration && `duy trì ${duration}`].filter(Boolean).join(' · ') || item.reason;
}

export function AlertsManagementPage() {
  const [items, setItems] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [attempt, setAttempt] = useState(0);
  const [typeFilter, setTypeFilter] = useState<TypeFilter>('ALL');
  const [severityFilter, setSeverityFilter] = useState<SeverityFilter>('ALL');
  const [busyId, setBusyId] = useState<number | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<NotificationItem | null>(null);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  useEffect(() => {
    let disposed = false;
    const controller = new AbortController();
    const load = (showLoading: boolean) => {
      if (showLoading) setLoading(true);
      fetchNotifications(false, controller.signal)
        .then(next => { if (!disposed) { setItems(next); setError(null); } })
        .catch(reason => { if (!disposed && reason?.name !== 'AbortError') setError(reason instanceof Error ? reason.message : 'Không thể tải cảnh báo.'); })
        .finally(() => { if (!disposed) setLoading(false); });
    };
    load(true);
    const timer = window.setInterval(() => load(false), 15_000);
    return () => { disposed = true; controller.abort(); window.clearInterval(timer); };
  }, [attempt]);

  const filtered = useMemo(() => items.filter(item => {
    const typeMatch = typeFilter === 'ALL' || (typeFilter === 'OFF_ROUTE_DETECTED' ? item.type === typeFilter : isReroute(item.type));
    return typeMatch && (severityFilter === 'ALL' || item.severity === severityFilter);
  }), [items, severityFilter, typeFilter]);
  const unread = items.filter(item => !item.readAt).length;
  const offRouteCount = items.filter(item => item.type === 'OFF_ROUTE_DETECTED').length;

  const read = async (item: NotificationItem) => {
    if (busyId !== null || item.readAt) return;
    setBusyId(item.id); setError(null);
    try {
      const updated = await markNotificationRead(item.id);
      setItems(current => current.map(row => row.id === updated.id ? updated : row));
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Không thể cập nhật cảnh báo.'); }
    finally { setBusyId(null); }
  };
  const readAll = async () => {
    if (busyId !== null || unread === 0) return;
    setBusyId(-1); setError(null);
    try {
      await markAllNotificationsRead();
      const now = new Date().toISOString();
      setItems(current => current.map(item => item.readAt ? item : { ...item, readAt: now }));
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Không thể đánh dấu cảnh báo.'); }
    finally { setBusyId(null); }
  };
  const remove = async () => {
    if (!confirmDelete || busyId !== null) return;
    setBusyId(confirmDelete.id); setDeleteError(null);
    try {
      await deleteNotification(confirmDelete.id);
      setItems(current => current.filter(item => item.id !== confirmDelete.id));
      setConfirmDelete(null);
    } catch (reason) { setDeleteError(reason instanceof Error ? reason.message : 'Không thể xóa cảnh báo.'); }
    finally { setBusyId(null); }
  };

  return <div className="business-page alerts-management-page">
    <PageHeading eyebrow="GIÁM SÁT & XỬ LÝ" title="Cảnh báo vận hành" description="Theo dõi sự cố, xác nhận xử lý và kiểm tra hành trình liên quan."
      actions={<button className="business-button" onClick={() => setAttempt(value => value + 1)} disabled={loading}><RefreshCw size={16} />Làm mới</button>} />
    <section className="alerts-metrics" aria-label="Chỉ số cảnh báo" aria-busy={loading}>
      <article><BellRing size={19} /><div><span>Đang hiển thị</span><strong>{loading ? '—' : items.length}</strong><small>Tối đa 50 cảnh báo gần nhất</small></div></article>
      <article><AlertTriangle size={19} /><div><span>Chưa đọc</span><strong>{loading ? '—' : unread}</strong></div></article>
      <article><MapPinned size={19} /><div><span>Lệch tuyến</span><strong>{loading ? '—' : offRouteCount}</strong></div></article>
    </section>
    {error && <section className="alerts-error" role="alert"><AlertTriangle size={18} /><div><strong>Không thể tải cảnh báo</strong><p>{error}</p></div><button onClick={() => setAttempt(value => value + 1)}>Thử lại</button></section>}
    <section className="business-surface alerts-list-panel">
      <div className="alerts-list-heading"><div><h2>Danh sách cảnh báo</h2><p>Cập nhật tự động mỗi 15 giây.</p></div><button className="alerts-read-all" disabled={busyId !== null || unread === 0} onClick={() => void readAll()}><CheckCheck size={14} />Đọc tất cả</button></div>
      <div className="alerts-filters"><label>Loại<select value={typeFilter} onChange={event => setTypeFilter(event.target.value as TypeFilter)}><option value="ALL">Tất cả</option><option value="OFF_ROUTE_DETECTED">Lệch tuyến</option><option value="REROUTE">Đổi tuyến</option></select></label><label>Mức độ<select value={severityFilter} onChange={event => setSeverityFilter(event.target.value as SeverityFilter)}><option value="ALL">Tất cả</option><option value="CRITICAL">Nghiêm trọng</option><option value="MAJOR">Cao</option></select></label><span>{filtered.length} cảnh báo phù hợp</span></div>
      {loading && <p className="alerts-state" role="status">Đang tải cảnh báo…</p>}
      {!loading && !error && filtered.length === 0 && <div className="alerts-empty-state"><BellRing size={30} /><strong>{items.length ? 'Không có cảnh báo phù hợp' : 'Chưa có cảnh báo'}</strong><p>{items.length ? 'Thử thay đổi bộ lọc để xem các cảnh báo khác.' : 'Hệ thống sẽ hiển thị cảnh báo khi phát hiện xe lệch khỏi tuyến được giao.'}</p></div>}
      {!loading && filtered.length > 0 && <div className="alerts-management-list">{filtered.map(item => <article key={item.id} className={`alerts-management-card ${item.readAt ? 'read' : 'unread'}`}>
        <div className={`alerts-management-icon ${item.type === 'OFF_ROUTE_DETECTED' ? 'off-route' : 'reroute'}`}>{item.type === 'OFF_ROUTE_DETECTED' ? <MapPinned size={18} /> : <Route size={18} />}</div>
        <div className="alerts-management-body"><div className="alerts-management-top"><span className={`alerts-severity ${item.severity.toLowerCase()}`}>{item.severity === 'CRITICAL' ? 'Nghiêm trọng' : 'Cao'}</span><time>{formatDateTime(item.createdAt)}</time></div><h3>{item.title}</h3><p>{item.vehiclePlateNumber} · Chuyến #{item.tripId}</p><strong>{alertDetail(item)}</strong><div className="alerts-management-actions"><Link to={`/operations?tripId=${item.tripId}`}>Mở giám sát</Link>{!item.readAt && <button disabled={busyId !== null} onClick={() => void read(item)}><Check size={14} />Đã xử lý</button>}<button disabled={busyId !== null} onClick={() => { setDeleteError(null); setConfirmDelete(item); }}><Trash2 size={14} />Xóa</button></div></div>
      </article>)}</div>}
    </section>
    {confirmDelete && <FleetConfirmDialog title="Xóa cảnh báo?" message="Cảnh báo sẽ bị xóa khỏi danh sách. Dữ liệu telemetry và trip không bị ảnh hưởng." confirmLabel="Xác nhận xóa" busy={busyId !== null} error={deleteError} onClose={() => setConfirmDelete(null)} onConfirm={() => { void remove(); }} />}
  </div>;
}
