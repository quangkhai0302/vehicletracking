import { useEffect, useMemo, useState } from 'react';
import { CalendarClock, CheckCircle2, ChevronRight, Clock3, LogOut, MapPin, Navigation, Route, UserRound, X } from 'lucide-react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { fetchMySchedules, fetchMyTrip, fetchMyTrips } from '../services/driverPortal';
import type { TripDetail, TripSummary } from '../types/fleet';
import type { TripSchedule } from '../types/schedule';
import { TRIP_STATUS_LABELS } from '../types/fleet';
import './driver-portal.css';
import { SidePanel } from '../components/business/SidePanel';

const BUSINESS_TIME_ZONE = 'Asia/Ho_Chi_Minh';
const dateTime = (value: string | null) => value ? new Intl.DateTimeFormat('vi-VN', { dateStyle: 'medium', timeStyle: 'short', timeZone: BUSINESS_TIME_ZONE }).format(new Date(value)) : 'Chưa có';
const businessDateKey = (value: Date | string) => {
  const parts = new Intl.DateTimeFormat('en', {
    timeZone: BUSINESS_TIME_ZONE,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(new Date(value));
  const values = Object.fromEntries(parts.map(part => [part.type, part.value]));
  return `${values.year}-${values.month}-${values.day}`;
};
const todayBusinessDate = () => businessDateKey(new Date());

export function DriverPortalPage() {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [trips, setTrips] = useState<TripSummary[]>([]);
  const [schedules, setSchedules] = useState<TripSchedule[]>([]);
  const [detail, setDetail] = useState<TripDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [attempt, setAttempt] = useState(0);
  const schedulesView = location.pathname.endsWith('/schedules');

  useEffect(() => {
    const controller = new AbortController();
    setLoading(true); setError(null);
    Promise.all([fetchMyTrips({}, controller.signal), fetchMySchedules(controller.signal)])
      .then(([nextTrips, nextSchedules]) => { if (!controller.signal.aborted) { setTrips(nextTrips); setSchedules(nextSchedules); } })
      .catch(reason => { if (!controller.signal.aborted) setError(reason instanceof Error ? reason.message : 'Không thể tải dữ liệu được phân công.'); })
      .finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
  }, [attempt]);

  const todayTrips = useMemo(() => trips.filter(trip => businessDateKey(trip.scheduledDepartureAt) === todayBusinessDate()), [trips]);
  const nextTrip = useMemo(() => trips.filter(trip => trip.status === 'SCHEDULED' || trip.status === 'IN_PROGRESS').sort((a, b) => Date.parse(a.scheduledDepartureAt) - Date.parse(b.scheduledDepartureAt))[0], [trips]);
  const openTrip = async (trip: TripSummary) => {
    try { setDetail(await fetchMyTrip(trip.id)); } catch (reason) { setError(reason instanceof Error ? reason.message : 'Không thể tải chi tiết chuyến.'); }
  };
  const signOut = async () => { await logout(); navigate('/login', { replace: true }); };

  return <main className="driver-portal business-ui"><header className="driver-portal-header"><div className="driver-portal-brand"><span><Navigation size={19} /></span><div><strong>Vehicle Tracking</strong><small>Cổng tài xế</small></div></div><div className="driver-portal-account"><UserRound size={16} /><span>{user?.driverName ?? user?.username}</span><button onClick={() => void signOut()}><LogOut size={15} />Đăng xuất</button></div></header>
    <div className="driver-portal-content"><section className="driver-welcome"><div><span>LỊCH TRÌNH CỦA TÔI</span><h1>Xin chào, {user?.driverName ?? 'tài xế'}</h1><p>Chỉ hiển thị chuyến đi và lịch chạy được điều phối cho bạn.</p></div><div className="driver-welcome-icon"><UserRound size={30} /></div></section>
      <nav className="driver-tabs"><Link className={!schedulesView ? 'active' : undefined} to="/driver/today"><Clock3 size={16} />Chuyến của tôi</Link><Link className={schedulesView ? 'active' : undefined} to="/driver/schedules"><CalendarClock size={16} />Lịch chạy</Link></nav>
      {error && <div className="driver-error" role="alert"><span>{error}</span><button onClick={() => setAttempt(value => value + 1)}>Thử lại</button></div>}
      {!schedulesView && <><section className="driver-summary-grid"><article><Clock3 size={20} /><span>Chuyến hôm nay<strong>{loading ? '—' : todayTrips.length}</strong></span></article><article><Route size={20} /><span>Chuyến kế tiếp<strong>{loading ? '—' : nextTrip ? `#${nextTrip.id}` : 'Không có'}</strong></span></article><article><CheckCircle2 size={20} /><span>Đã hoàn thành<strong>{loading ? '—' : trips.filter(trip => trip.status === 'COMPLETED').length}</strong></span></article></section><section className="driver-panel"><div className="driver-panel-heading"><div><h2>Chuyến được phân công</h2><p>Chọn một chuyến để xem lịch trình và các điểm dừng.</p></div><span>{loading ? 'Đang tải…' : `${trips.length} chuyến`}</span></div>{loading && <p className="driver-state">Đang tải chuyến đi…</p>}{!loading && trips.length === 0 && <div className="driver-empty"><Route size={30} /><strong>Chưa có chuyến được phân công</strong><p>Điều phối viên sẽ hiển thị chuyến mới tại đây.</p></div>}{!loading && trips.length > 0 && <div className="driver-trip-list">{trips.map(trip => <button key={trip.id} className="driver-trip-card" onClick={() => void openTrip(trip)}><span className="driver-trip-id">#{trip.id}</span><span><strong>{trip.routeName}</strong><small>{trip.vehiclePlateNumber} · {dateTime(trip.scheduledDepartureAt)}</small></span><span className={`driver-status ${trip.status.toLowerCase()}`}>{TRIP_STATUS_LABELS[trip.status]}</span><ChevronRight size={17} /></button>)}</div>}</section></>}
      {schedulesView && <section className="driver-panel"><div className="driver-panel-heading"><div><h2>Lịch chạy được giao</h2><p>Lịch cố định có tài xế là bạn.</p></div><span>{loading ? 'Đang tải…' : `${schedules.length} lịch`}</span></div>{loading && <p className="driver-state">Đang tải lịch chạy…</p>}{!loading && schedules.length === 0 && <div className="driver-empty"><CalendarClock size={30} /><strong>Chưa có lịch chạy</strong><p>Liên hệ điều phối viên nếu bạn cần cập nhật phân công.</p></div>}{!loading && schedules.map(schedule => <article className="driver-schedule-card" key={schedule.id}><div className="driver-schedule-icon"><CalendarClock size={19} /></div><div><strong>{schedule.name || schedule.routeName}</strong><p>{schedule.routeName} · {schedule.vehiclePlate}</p><small>{schedule.frequency === 'WEEKLY' ? `Hàng tuần · ${schedule.departureTime.slice(0, 5)}` : `Một lần · ${schedule.scheduledDate ?? '—'}`} · {schedule.timezone}</small></div><span className={schedule.enabled ? 'driver-schedule-active' : 'driver-schedule-paused'}>{schedule.enabled ? 'Đang hoạt động' : 'Tạm dừng'}</span></article>)}</section>}
    </div>
    {detail && <SidePanel className="driver-detail" label="Chi tiết chuyến được phân công" onClose={() => setDetail(null)}><header><div><span>CHI TIẾT CHUYẾN #{detail.trip.id}</span><h2>{detail.trip.routeName}</h2></div><button aria-label="Đóng chi tiết" onClick={() => setDetail(null)}><X size={19} /></button></header><div className="driver-detail-meta"><div><MapPin size={16} /><span>Xe<strong>{detail.trip.vehiclePlateNumber}</strong></span></div><div><Clock3 size={16} /><span>Khởi hành<strong>{dateTime(detail.trip.scheduledDepartureAt)}</strong></span></div></div><div className="driver-stop-list"><h3>Trình tự điểm dừng</h3>{detail.stops.map(stop => <div key={stop.sequenceNumber}><span>{stop.sequenceNumber}</span><div><strong>{stop.stationName}</strong><small>Dự kiến đến {dateTime(stop.plannedArrivalAt)}</small></div></div>)}</div></SidePanel>}
  </main>;
}
