import { useEffect, useMemo, useState } from 'react';
import { AlertTriangle, BarChart3, BusFront, CalendarRange, CheckCircle2, Clock3, Gauge, MapPinned, RefreshCw, Route, UserRound } from 'lucide-react';
import { fetchDrivers, fetchFleetVehicles } from '../services/fleet';
import { fetchOperationalReport } from '../services/reports';
import type { Driver, FleetVehicle } from '../types/fleet';
import type { OperationalReport, OperationalReportFilters } from '../types/reports';
import './reports.css';
import { PageHeading } from '../components/business/PageHeading';

interface ReportData { report?: OperationalReport; vehicles: FleetVehicle[]; drivers: Driver[] }

function dateInUtc(offsetDays: number) {
  const date = new Date();
  date.setUTCDate(date.getUTCDate() + offsetDays);
  return date.toISOString().slice(0, 10);
}

function formatDistance(meters: number) {
  return new Intl.NumberFormat('vi-VN', { maximumFractionDigits: 1 }).format(meters / 1000);
}

function formatRuntime(seconds: number) {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  if (hours === 0) return `${minutes} phút`;
  return `${hours} giờ ${minutes} phút`;
}

function formatDate(value: string) {
  if (!value) return '—';
  return new Intl.DateTimeFormat('vi-VN', { dateStyle: 'medium', timeZone: 'UTC' }).format(new Date(`${value}T00:00:00Z`));
}

export function ReportsPage() {
  const [filters, setFilters] = useState<OperationalReportFilters>({ from: dateInUtc(-29), to: dateInUtc(0) });
  const [data, setData] = useState<ReportData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    if (!filters.from || !filters.to) return undefined;
    const controller = new AbortController();
    Promise.all([fetchOperationalReport(filters, controller.signal), fetchFleetVehicles(controller.signal), fetchDrivers(controller.signal)])
      .then(([report, vehicles, drivers]) => { if (!controller.signal.aborted) { setData({ report, vehicles, drivers }); setError(null); } })
      .catch((reason: unknown) => { if (!controller.signal.aborted) setError(reason instanceof Error ? reason.message : 'Không thể tải báo cáo vận hành.'); })
      .finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
  }, [filters, attempt]);

  const vehicles = useMemo(() => data?.vehicles ?? [], [data]);
  const drivers = useMemo(() => data?.drivers ?? [], [data]);
  const applyFilters = (next: OperationalReportFilters) => {
    if (!next.from || !next.to) {
      setLoading(false);
      setError('Hãy chọn đầy đủ ngày bắt đầu và ngày kết thúc.');
    } else {
      setLoading(true);
      setError(null);
      setData(current => current ? { ...current, report: undefined } : current);
    }
    setFilters(next);
  };
  const updateFilter = (key: keyof OperationalReportFilters, value: string) => applyFilters({ ...filters, [key]: value });
  const applyVehicle = (value: string) => applyFilters({ ...filters, vehicleId: value ? Number(value) : undefined });
  const applyDriver = (value: string) => applyFilters({ ...filters, driverId: value ? Number(value) : undefined });
  const resetFilters = () => applyFilters({ from: dateInUtc(-29), to: dateInUtc(0) });

  const report = data?.report;
  const metrics = report ? [
    { label: 'Tổng số chuyến', value: report.tripCount.toLocaleString('vi-VN'), detail: `${report.completedTripCount.toLocaleString('vi-VN')} chuyến đã hoàn thành`, icon: Route, tone: 'blue' },
    { label: 'Tổng quãng đường tuyến', value: `${formatDistance(report.totalDistanceMeters)} km`, detail: 'Theo tổng chiều dài tuyến đã lập', icon: MapPinned, tone: 'cyan' },
    { label: 'Tổng thời gian chạy', value: formatRuntime(report.totalRunningSeconds), detail: 'Từ thời điểm bắt đầu đến kết thúc', icon: Clock3, tone: 'violet' },
    { label: 'Tỷ lệ đúng giờ', value: `${report.onTimeRatePercent.toLocaleString('vi-VN')}%`, detail: 'Trong các chuyến đã hoàn thành', icon: CheckCircle2, tone: 'green' },
    { label: 'Chuyến bị trễ', value: report.lateTripCount.toLocaleString('vi-VN'), detail: 'Đã kết thúc trễ hoặc đang quá giờ', icon: AlertTriangle, tone: 'red' },
    { label: 'Lần lệch tuyến', value: report.offRouteEventCount.toLocaleString('vi-VN'), detail: 'Cảnh báo lệch tuyến được ghi nhận', icon: MapPinned, tone: 'amber' },
    { label: 'Lần vượt ngưỡng tốc độ', value: report.overspeedEventCount.toLocaleString('vi-VN'), detail: `Theo ngưỡng ${report.speedLimitKmh.toLocaleString('vi-VN')} km/h`, icon: Gauge, tone: 'rose' },
  ] : [];

  return <div className="business-page reports-page">
    <PageHeading eyebrow="PHÂN TÍCH HIỆU SUẤT" title="Báo cáo và thống kê" description="Đối soát hiệu suất chuyến đi theo thời gian, phương tiện và tài xế." />

    <section className="business-surface reports-filter-panel" aria-label="Bộ lọc báo cáo">
      <div className="reports-filter-heading"><div><h2>Phạm vi báo cáo</h2><p>Ngày được tính theo thời điểm khởi hành dự kiến của chuyến.</p></div><button type="button" className="reports-reset" onClick={resetFilters}>Xóa bộ lọc</button></div>
      <div className="reports-filters">
        <label><span>Từ ngày</span><input required type="date" value={filters.from} max={filters.to} onChange={event => updateFilter('from', event.target.value)} /></label>
        <label><span>Đến ngày</span><input required type="date" value={filters.to} min={filters.from} onChange={event => updateFilter('to', event.target.value)} /></label>
        <label><span>Phương tiện</span><select value={filters.vehicleId ?? ''} onChange={event => applyVehicle(event.target.value)}><option value="">Tất cả phương tiện</option>{vehicles.map(vehicle => <option key={vehicle.id} value={vehicle.id}>{vehicle.plateNumber} · {vehicle.name}{vehicle.active ? '' : ' · Ngừng sử dụng'}</option>)}</select></label>
        <label><span>Tài xế</span><select value={filters.driverId ?? ''} onChange={event => applyDriver(event.target.value)}><option value="">Tất cả tài xế</option>{drivers.map(driver => <option key={driver.id} value={driver.id}>{driver.fullName} · {driver.licenseNumber}{driver.active ? '' : ' · Ngừng hoạt động'}</option>)}</select></label>
      </div>
      <div className="reports-filter-note"><CalendarRange size={15} /><span>{formatDate(filters.from)} – {formatDate(filters.to)}</span><span className="reports-filter-separator">·</span><span>{filters.vehicleId ? 'Đã lọc theo xe' : 'Toàn bộ xe'} · {filters.driverId ? 'Đã lọc theo tài xế' : 'Toàn bộ tài xế'}</span></div>
    </section>

    {error && <section className="reports-error" role="alert"><AlertTriangle size={19} /><div><strong>Không thể tải báo cáo</strong><p>{error}</p></div>{filters.from && filters.to && <button type="button" onClick={() => { setLoading(true); setError(null); setAttempt(value => value + 1); }}><RefreshCw size={14} />Thử lại</button>}</section>}

    <section className="reports-metrics" aria-label="Chỉ số báo cáo" aria-busy={loading}>
      {metrics.map(metric => { const Icon = metric.icon; return <article key={metric.label} className={`reports-metric ${metric.tone}`}><span className="reports-metric-icon"><Icon size={19} /></span><div><span>{metric.label}</span><strong>{loading || !report ? '—' : metric.value}</strong><small>{metric.detail}</small></div></article>; })}
      {loading && !report && <div className="reports-loading" role="status"><RefreshCw size={18} /><span>Đang tải báo cáo vận hành…</span></div>}
      {!loading && report?.tripCount === 0 && !error && <div className="reports-empty"><BarChart3 size={30} /><strong>Không có chuyến trong phạm vi này</strong><p>Thử chọn khoảng thời gian khác hoặc bỏ bớt bộ lọc.</p></div>}
    </section>

    <section className="business-surface reports-definition">
      <div><div className="reports-definition-icon"><BusFront size={18} /></div><div><h2>Định nghĩa chỉ số</h2><p>Quãng đường dùng chiều dài tuyến đã lập; thời gian chạy dùng timestamp thực tế. Quá tốc độ chỉ tính dữ liệu GPS và gộp các mẫu liên tiếp thành một lần vi phạm.</p></div></div>
      <div><UserRound size={16} /><span>Lọc tài xế dựa trên tài xế đang gán cho chuyến.</span></div>
    </section>
  </div>;
}
