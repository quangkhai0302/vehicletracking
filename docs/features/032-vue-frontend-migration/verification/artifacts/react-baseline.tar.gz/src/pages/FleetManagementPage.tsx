import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { FleetWorkspace } from '../components/fleet/FleetWorkspace';
import type { FleetTab } from '../hooks/useFleetWorkspace';

export function FleetManagementPage({ tab }: { tab: FleetTab }) {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [toast, setToast] = useState<string | null>(null);
  const vehicleFilterValue = Number(searchParams.get('vehicleId'));
  const initialVehicleFilter = tab === 'trips' && Number.isInteger(vehicleFilterValue) && vehicleFilterValue > 0 ? vehicleFilterValue : null;

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 3200);
    return () => window.clearTimeout(timer);
  }, [toast]);

  return <div className="business-page">
    <section className="business-surface business-management-surface">
      <FleetWorkspace
        initialTab={tab}
        initialVehicleFilter={initialVehicleFilter}
        lockedTab={tab}
        onToast={setToast}
        onFocusStop={() => navigate('/operations')}
        onManageRoutes={() => navigate('/routes')}
        onManageStations={() => navigate('/stations')}
        onSimulateTrip={() => navigate('/operations')}
        onFocusVehicle={() => navigate('/operations')}
        onViewVehicleTrips={vehicleId => navigate(`/trips?vehicleId=${vehicleId}`)}
        onClearVehicleFilter={() => navigate('/trips', { replace: true })}
      />
    </section>
    {toast && <div className="business-toast" role="status">{toast}</div>}
  </div>;
}
