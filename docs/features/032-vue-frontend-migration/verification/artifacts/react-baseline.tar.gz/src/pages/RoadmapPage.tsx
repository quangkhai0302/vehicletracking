import { ArrowRight, CheckCircle2, CircleDashed, Construction } from 'lucide-react';
import { Link } from 'react-router-dom';

interface RoadmapPageProps {
  title: string;
  summary: string;
  capabilities: string[];
  dependency: string;
  nextPath: string;
  nextLabel: string;
}

export function RoadmapPage({ title, summary, capabilities, dependency, nextPath, nextLabel }: RoadmapPageProps) {
  return <div className="business-page roadmap-page">
    <section className="roadmap-hero business-surface">
      <span className="roadmap-icon"><Construction size={24} /></span>
      <div><span>ĐANG TRONG LỘ TRÌNH</span><h2>{title}</h2><p>{summary}</p></div>
    </section>
    <div className="roadmap-grid">
      <section className="business-surface roadmap-card"><h2>Phạm vi dự kiến</h2><ul>{capabilities.map(item => <li key={item}><CircleDashed size={16} /><span>{item}</span></li>)}</ul></section>
      <section className="business-surface roadmap-card roadmap-dependency"><h2>Điều kiện để triển khai</h2><p>{dependency}</p><div><CheckCircle2 size={16} /><span>Không hiển thị dữ liệu mẫu như dữ liệu vận hành thật.</span></div></section>
    </div>
    <Link className="roadmap-next-link" to={nextPath}>{nextLabel}<ArrowRight size={16} /></Link>
  </div>;
}
